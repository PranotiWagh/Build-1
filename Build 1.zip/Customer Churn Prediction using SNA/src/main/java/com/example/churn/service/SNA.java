package com.example.churn.service;

import org.jgrapht.Graph;
import org.jgrapht.alg.scoring.BetweennessCentrality;
import org.jgrapht.alg.scoring.ClosenessCentrality;
import org.jgrapht.Graphs;
import org.jgrapht.alg.scoring.PageRank;
import org.jgrapht.graph.DefaultDirectedWeightedGraph;
import org.jgrapht.graph.DefaultWeightedEdge;

import org.springframework.stereotype.Service;

import tech.tablesaw.api.DoubleColumn;
import tech.tablesaw.api.Row;
import tech.tablesaw.api.StringColumn;
import tech.tablesaw.api.Table;

import java.util.HashMap;
import java.util.Map;

@Service
public class SNA {

    public Table calculateSNA(Table cdrTable) {

        if (cdrTable == null ||
                cdrTable.rowCount() == 0) {

            return createEmptyResult();
        }

        if (!cdrTable.columnNames()
                .contains("Caller id")) {

            throw new IllegalArgumentException(
                    "CDR table does not contain "
                            + "'Caller id'"
            );
        }

        if (!cdrTable.columnNames()
                .contains("Receiver id")) {

            throw new IllegalArgumentException(
                    "CDR table does not contain "
                            + "'Receiver id'"
            );
        }

        Graph<String, DefaultWeightedEdge> graph =
                new DefaultDirectedWeightedGraph<>(
                        DefaultWeightedEdge.class
                );

        /*
         * Build graph.
         */
        for (int i = 0;
             i < cdrTable.rowCount();
             i++) {

            Row row = cdrTable.row(i);

            String caller =
                    cleanId(
                            getValueAsString(
                                    row,
                                    "Caller id"
                            )
                    );

            String receiver =
                    cleanId(
                            getValueAsString(
                                    row,
                                    "Receiver id"
                            )
                    );

            if (caller.isEmpty() ||
                    receiver.isEmpty()) {

                continue;
            }

            if (caller.equals(receiver)) {
                continue;
            }

            graph.addVertex(caller);
            graph.addVertex(receiver);

            DefaultWeightedEdge edge =
                    graph.getEdge(
                            caller,
                            receiver
                    );

            if (edge == null) {

                edge = graph.addEdge(
                        caller,
                        receiver
                );

                if (edge != null) {
                    graph.setEdgeWeight(
                            edge,
                            1.0
                    );
                }

            } else {

                graph.setEdgeWeight(
                        edge,
                        graph.getEdgeWeight(edge)
                                + 1.0
                );
            }
        }

        /*
         * Centrality algorithms.
         */
        BetweennessCentrality<String,
                DefaultWeightedEdge>
                betweennessCentrality =
                new BetweennessCentrality<>(
                        graph
                );

        ClosenessCentrality<String,
                DefaultWeightedEdge>
                closenessCentrality =
                new ClosenessCentrality<>(
                        graph
                );

        PageRank<String,
                DefaultWeightedEdge>
                pageRank =
                new PageRank<>(graph);

        Map<String, Double> betweenness =
                betweennessCentrality.getScores();

        Map<String, Double> closeness =
                closenessCentrality.getScores();

        Map<String, Double> influence =
                pageRank.getScores();

        Map<String, Double> conformity =
                calculateConformity(graph);

        StringColumn customerId =
                StringColumn.create(
                        "customer_id"
                );

        DoubleColumn inDegree =
                DoubleColumn.create(
                        "in_degree"
                );

        DoubleColumn outDegree =
                DoubleColumn.create(
                        "out_degree"
                );

        DoubleColumn totalDegree =
                DoubleColumn.create(
                        "total_degree"
                );

        DoubleColumn between =
                DoubleColumn.create(
                        "betweenness"
                );

        DoubleColumn close =
                DoubleColumn.create(
                        "closeness"
                );

        DoubleColumn pageRankColumn =
                DoubleColumn.create(
                        "influence"
                );

        DoubleColumn conformityColumn =
                DoubleColumn.create(
                        "conformity"
                );

        for (String vertex :
                graph.vertexSet()) {

            customerId.append(vertex);

            double in =
                    graph.inDegreeOf(vertex);

            double out =
                    graph.outDegreeOf(vertex);

            inDegree.append(in);
            outDegree.append(out);
            totalDegree.append(in + out);

            between.append(
                    safeMapValue(
                            betweenness,
                            vertex
                    )
            );

            close.append(
                    safeMapValue(
                            closeness,
                            vertex
                    )
            );

            pageRankColumn.append(
                    safeMapValue(
                            influence,
                            vertex
                    )
            );

            conformityColumn.append(
                    safeMapValue(
                            conformity,
                            vertex
                    )
            );
        }

        return Table.create(
                "SNA Features",
                customerId,
                inDegree,
                outDegree,
                totalDegree,
                between,
                close,
                pageRankColumn,
                conformityColumn
        );
    }

    private Map<String, Double>
    calculateConformity(
            Graph<String, DefaultWeightedEdge> graph) {

        Map<String, Double> result =
                new HashMap<>();

        for (String customer :
                graph.vertexSet()) {

            double customerDegree =
                    graph.degreeOf(customer);

            double neighborDegreeSum = 0.0;

            int neighborCount = 0;

            for (String neighbor :
                    Graphs.successorListOf(
                        graph,
                        customer
                )) {

                neighborDegreeSum +=
                        graph.degreeOf(neighbor);

                neighborCount++;
            }

            for (String neighbor :
                    Graphs.predecessorListOf(
                        graph,
                        customer
                )) {

                if (!neighbor.equals(customer)) {

                    neighborDegreeSum +=
                            graph.degreeOf(neighbor);

                    neighborCount++;
                }
            }

            if (neighborCount == 0) {

                result.put(
                        customer,
                        0.0
                );

                continue;
            }

            double averageNeighborDegree =
                    neighborDegreeSum /
                            neighborCount;

            double conformityValue =
                    1.0 /
                            (
                                    1.0 +
                                            Math.abs(
                                                    customerDegree
                                                            - averageNeighborDegree
                                            )
                            );

            result.put(
                    customer,
                    conformityValue
            );
        }

        return result;
    }

    public CustomerSNAResult getCustomerSNA(
            Table networkFeatures,
            String customerId) {

        if (networkFeatures == null ||
                customerId == null) {

            return null;
        }

        for (int i = 0;
             i < networkFeatures.rowCount();
             i++) {

            Row row =
                    networkFeatures.row(i);

            String id =
                    getValueAsString(
                            row,
                            "customer_id"
                    );

            if (customerId.equalsIgnoreCase(
                    id
            )) {

                return new CustomerSNAResult(

                        getDoubleValue(
                                row,
                                "in_degree"
                        ),

                        getDoubleValue(
                                row,
                                "out_degree"
                        ),

                        getDoubleValue(
                                row,
                                "total_degree"
                        ),

                        getDoubleValue(
                                row,
                                "betweenness"
                        ),

                        getDoubleValue(
                                row,
                                "closeness"
                        ),

                        getDoubleValue(
                                row,
                                "influence"
                        ),

                        getDoubleValue(
                                row,
                                "conformity"
                        )
                );
            }
        }

        /*
         * No matching CDR node.
         */
        return new CustomerSNAResult(
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0
        );
    }

    private Table createEmptyResult() {

        return Table.create(
                "SNA Features",
                StringColumn.create(
                        "customer_id"
                ),
                DoubleColumn.create(
                        "in_degree"
                ),
                DoubleColumn.create(
                        "out_degree"
                ),
                DoubleColumn.create(
                        "total_degree"
                ),
                DoubleColumn.create(
                        "betweenness"
                ),
                DoubleColumn.create(
                        "closeness"
                ),
                DoubleColumn.create(
                        "influence"
                ),
                DoubleColumn.create(
                        "conformity"
                )
        );
    }

    private String getValueAsString(
            Row row,
            String columnName) {

        try {

            Object value =
                    row.getObject(columnName);

            if (value == null) {
                return "";
            }

            return String.valueOf(value)
                    .trim();

        } catch (Exception e) {

            return "";
        }
    }

    private double getDoubleValue(
            Row row,
            String columnName) {

        try {

            Object value =
                    row.getObject(columnName);

            if (value == null) {
                return 0.0;
            }

            return Double.parseDouble(
                    String.valueOf(value)
            );

        } catch (Exception e) {

            return 0.0;
        }
    }

    private String cleanId(String value) {

        if (value == null) {
            return "";
        }

        String cleaned =
                value
                        .trim()
                        .replace("\"", "")
                        .replace(
                                "\uFEFF",
                                ""
                        );

        if (cleaned.matches(
                "\\d+\\.0+"
        )) {

            cleaned =
                    cleaned.substring(
                            0,
                            cleaned.indexOf('.')
                    );
        }

        return cleaned;
    }

    private double safeMapValue(
            Map<String, Double> map,
            String key) {

        Double value =
                map.get(key);

        return value == null
                ? 0.0
                : value;
    }

    public static class CustomerSNAResult {

        private final double inDegree;
        private final double outDegree;
        private final double totalDegree;
        private final double betweenness;
        private final double closeness;
        private final double influence;
        private final double conformity;

        public CustomerSNAResult(
                double inDegree,
                double outDegree,
                double totalDegree,
                double betweenness,
                double closeness,
                double influence,
                double conformity) {

            this.inDegree = inDegree;
            this.outDegree = outDegree;
            this.totalDegree = totalDegree;
            this.betweenness = betweenness;
            this.closeness = closeness;
            this.influence = influence;
            this.conformity = conformity;
        }

        public double getInDegree() {
            return inDegree;
        }

        public double getOutDegree() {
            return outDegree;
        }

        public double getTotalDegree() {
            return totalDegree;
        }

        public double getBetweenness() {
            return betweenness;
        }

        public double getCloseness() {
            return closeness;
        }

        public double getInfluence() {
            return influence;
        }

        public double getConformity() {
            return conformity;
        }
    }
}