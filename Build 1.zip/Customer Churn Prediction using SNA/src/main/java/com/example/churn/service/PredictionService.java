package com.example.churn.service;

import com.example.churn.dto.ChurnPredictionResult;
import com.example.churn.dto.NewCustomerDto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tech.tablesaw.api.Table;

@Service
public class PredictionService {

    @Autowired
    private ML ml;

    @Autowired
    private ModelTrainingService modelTrainingService;

    @Autowired
    private DataPreprocessing dataPreprocessing;

    @Autowired
    private SNA sna;

    @Autowired
    private FeatureMerging featureMerging;


    /*
     * ============================================================
     * EXISTING CUSTOMER PREDICTION
     * ============================================================
     *
     * GET
     * /api/prediction/customer/{customerId}
     */
    public ChurnPredictionResult predictExistingCustomer(
            String customerId) throws Exception {

        if (customerId == null ||
                customerId.trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Customer ID cannot be empty."
            );
        }

        customerId = customerId.trim();

        System.out.println();
        System.out.println("======================================");
        System.out.println("CUSTOMER CHURN PREDICTION");
        System.out.println("======================================");
        System.out.println("Customer ID : " + customerId);


        /*
         * ========================================================
         * 1. AUTOMATIC ML TRAINING
         * ========================================================
         */
        if (!ml.isModelTrained()) {

            System.out.println();
            System.out.println(
                    "ML models are not trained."
            );

            System.out.println(
                    "Starting automatic model training..."
            );

            modelTrainingService.trainModels();

            System.out.println(
                    "Automatic ML training completed."
            );
        }


        if (!ml.isModelTrained()) {

            throw new IllegalStateException(
                    "ML model training failed."
            );
        }


        /*
         * ========================================================
         * 2. LOAD CUSTOMER DATA
         * ========================================================
         */
        Table customerData =
                dataPreprocessing
                        .loadAndCleanCustomerData();


        /*
         * ========================================================
         * 3. LOAD CDR DATA
         * ========================================================
         */
        Table cdrData =
                dataPreprocessing
                        .loadAndCleanCDRData();


        /*
         * ========================================================
         * 4. CALCULATE SNA
         * ========================================================
         */
        Table networkFeatures =
                sna.calculateSNA(cdrData);


        /*
         * ========================================================
         * 5. MERGE CUSTOMER + SNA
         * ========================================================
         */
        Table finalDataset =
                featureMerging.merge(
                        customerData,
                        networkFeatures
                );


        System.out.println();
        System.out.println(
                "Final dataset rows : "
                        + finalDataset.rowCount()
        );

        System.out.println(
                "Final dataset columns : "
                        + finalDataset.columnNames()
        );


        /*
         * ========================================================
         * 6. CHECK CUSTOMER ID COLUMN
         * ========================================================
         */
        if (!finalDataset
                .columnNames()
                .contains("customerID")) {

            throw new IllegalArgumentException(
                    "Final dataset does not contain customerID."
            );
        }


        /*
         * ========================================================
         * 7. FIND CUSTOMER
         * ========================================================
         */
        int customerRowIndex = -1;

        for (int i = 0;
             i < finalDataset.rowCount();
             i++) {

            String id =
                    finalDataset
                            .stringColumn("customerID")
                            .get(i);

            if (id != null &&
                    id.trim().equalsIgnoreCase(customerId)) {

                customerRowIndex = i;
                break;
            }
        }


        if (customerRowIndex == -1) {

            throw new IllegalArgumentException(
                    "Customer ID not found: "
                            + customerId
            );
        }


        /*
         * ========================================================
         * 8. GET ONE CUSTOMER ROW
         * ========================================================
         */
        Table customerRow =
                finalDataset
                        .where(
                                finalDataset
                                        .stringColumn(
                                                "customerID"
                                        )
                                        .isEqualTo(
                                                finalDataset
                                                        .stringColumn(
                                                                "customerID"
                                                        )
                                                        .get(
                                                                customerRowIndex
                                                        )
                                        )
                        );


        /*
         * ========================================================
         * 9. CONVERT CUSTOMER ROW TO ML FEATURE VECTOR
         * ========================================================
         *
         * ML.java expects:
         *
         * double[]
         *
         * NOT:
         *
         * Table
         */
        double[] features =
                createFeatureVector(
                        customerRow
                );


        /*
         * ========================================================
         * 10. GRADIENT BOOSTING PREDICTION
         * ========================================================
         */
        ML.PrimaryPrediction prediction =
                ml.predictWithPrimaryModel(
                        features
                );


        /*
         * ========================================================
         * 11. GET SNA RESULT
         * ========================================================
         */
        SNA.CustomerSNAResult snaResult =
                sna.getCustomerSNA(
                        networkFeatures,
                        customerId
                );


        /*
         * ========================================================
         * 12. CREATE RESPONSE
         * ========================================================
         */
        ChurnPredictionResult result =
                new ChurnPredictionResult();


        result.setCustomerId(
                customerId
        );


        result.setFinalPrediction(
                prediction.getPrediction()
        );


        result.setChurnProbability(
                prediction.getProbability()
        );


        /*
         * IMPORTANT:
         *
         * Your current ChurnPredictionResult does NOT have
         * setRiskLevel(), so we don't call it here.
         */


        /*
         * ========================================================
         * 13. SET SNA VALUES
         * ========================================================
         */
        if (snaResult != null) {

            result.setInDegree(
                    snaResult.getInDegree()
            );

            result.setOutDegree(
                    snaResult.getOutDegree()
            );

            result.setTotalDegree(
                    snaResult.getTotalDegree()
            );

            result.setBetweenness(
                    snaResult.getBetweenness()
            );

            result.setCloseness(
                    snaResult.getCloseness()
            );

            result.setInfluence(
                    snaResult.getInfluence()
            );

            result.setConformity(
                    snaResult.getConformity()
            );
        }


        /*
         * ========================================================
         * 14. PRINT RESULT
         * ========================================================
         */
        System.out.println();
        System.out.println("======================================");
        System.out.println("PREDICTION RESULT");
        System.out.println("======================================");

        System.out.println(
                "Customer ID       : "
                        + customerId
        );

        System.out.println(
                "Prediction        : "
                        + prediction.getPrediction()
        );

        System.out.println(
                "Churn Probability : "
                        + prediction.getProbability()
        );

        System.out.println("======================================");


        return result;
    }


    /*
     * ============================================================
     * CREATE ML FEATURE VECTOR
     * ============================================================
     *
     * Your ML model uses 26 features.
     *
     * These correspond to the customer fields + SNA fields
     * used by ML.java.
     */
    private double[] createFeatureVector(
            Table row) {

        double[] features =
                new double[26];


        /*
         * Customer demographic / account fields
         */
        features[0] =
                numericValue(row, "SeniorCitizen");

        features[1] =
                numericValue(row, "tenure");

        features[2] =
                numericValue(row, "MonthlyCharges");

        features[3] =
                numericValue(row, "TotalCharges");


        /*
         * Phone / service features
         */
        features[4] =
                encodeBinary(row, "Partner");

        features[5] =
                encodeBinary(row, "Dependents");

        features[6] =
                encodeBinary(row, "PhoneService");

        features[7] =
                encodeBinary(row, "PaperlessBilling");


        /*
         * Multiple lines
         */
        features[8] =
                encodeCategory(
                        row,
                        "MultipleLines"
                );


        /*
         * Internet service
         */
        features[9] =
                encodeCategory(
                        row,
                        "InternetService"
                );


        /*
         * Online security
         */
        features[10] =
                encodeCategory(
                        row,
                        "OnlineSecurity"
                );


        /*
         * Online backup
         */
        features[11] =
                encodeCategory(
                        row,
                        "OnlineBackup"
                );


        /*
         * Device protection
         */
        features[12] =
                encodeCategory(
                        row,
                        "DeviceProtection"
                );


        /*
         * Tech support
         */
        features[13] =
                encodeCategory(
                        row,
                        "TechSupport"
                );


        /*
         * Streaming TV
         */
        features[14] =
                encodeCategory(
                        row,
                        "StreamingTV"
                );


        /*
         * Streaming movies
         */
        features[15] =
                encodeCategory(
                        row,
                        "StreamingMovies"
                );


        /*
         * Contract
         */
        features[16] =
                encodeCategory(
                        row,
                        "Contract"
                );


        /*
         * Payment method
         */
        features[17] =
                encodeCategory(
                        row,
                        "PaymentMethod"
                );


        /*
         * Gender
         */
        features[18] =
                encodeGender(row);


        /*
         * SNA features
         */
        features[19] =
                numericValue(
                        row,
                        "in_degree"
                );

        features[20] =
                numericValue(
                        row,
                        "out_degree"
                );

        features[21] =
                numericValue(
                        row,
                        "total_degree"
                );

        features[22] =
                numericValue(
                        row,
                        "betweenness"
                );

        features[23] =
                numericValue(
                        row,
                        "closeness"
                );

        features[24] =
                numericValue(
                        row,
                        "influence"
                );

        features[25] =
                numericValue(
                        row,
                        "conformity"
                );


        return features;
    }


    /*
     * ============================================================
     * NUMERIC VALUE
     * ============================================================
     */
    private double numericValue(
            Table row,
            String column) {

        if (!row.columnNames().contains(column)) {
            return 0.0;
        }

        try {

            return row
                    .doubleColumn(column)
                    .getDouble(0);

        } catch (Exception e) {

            try {

                return Double.parseDouble(
                        row
                                .column(column)
                                .getString(0)
                );

            } catch (Exception ignored) {

                return 0.0;
            }
        }
    }


    /*
     * ============================================================
     * BINARY ENCODING
     * ============================================================
     */
    private double encodeBinary(
            Table row,
            String column) {

        if (!row.columnNames().contains(column)) {
            return 0.0;
        }

        String value =
                row
                        .column(column)
                        .getString(0);

        if (value == null) {
            return 0.0;
        }

        value =
                value.trim()
                        .toLowerCase();


        if (value.equals("yes") ||
                value.equals("true") ||
                value.equals("1")) {

            return 1.0;
        }

        return 0.0;
    }


    /*
     * ============================================================
     * CATEGORY ENCODING
     * ============================================================
     */
    private double encodeCategory(
            Table row,
            String column) {

        if (!row.columnNames().contains(column)) {
            return 0.0;
        }

        String value =
                row
                        .column(column)
                        .getString(0);

        if (value == null) {
            return 0.0;
        }

        value =
                value.trim()
                        .toLowerCase();


        /*
         * Convert common categorical values into stable
         * numeric representations.
         */
        if (value.equals("no") ||
                value.equals("none") ||
                value.equals("no internet service") ||
                value.equals("no phone service")) {

            return 0.0;
        }


        if (value.equals("yes")) {
            return 1.0;
        }


        if (value.contains("fiber")) {
            return 2.0;
        }


        if (value.contains("dsl")) {
            return 1.0;
        }


        if (value.contains("month")) {
            return 0.0;
        }


        if (value.contains("one year")) {
            return 1.0;
        }


        if (value.contains("two year")) {
            return 2.0;
        }


        if (value.contains("electronic")) {
            return 1.0;
        }


        if (value.contains("mailed")) {
            return 2.0;
        }


        if (value.contains("bank")) {
            return 3.0;
        }


        if (value.contains("credit")) {
            return 4.0;
        }


        return 1.0;
    }


    /*
     * ============================================================
     * GENDER ENCODING
     * ============================================================
     */
    private double encodeGender(
            Table row) {

        if (!row.columnNames().contains("gender")) {
            return 0.0;
        }

        String gender =
                row
                        .column("gender")
                        .getString(0);

        if (gender == null) {
            return 0.0;
        }

        if (gender
                .trim()
                .equalsIgnoreCase("female")) {

            return 1.0;
        }

        return 0.0;
    }


    /*
     * ============================================================
     * NEW CUSTOMER PREDICTION
     * ============================================================
     *
     * Kept for PredictionController compatibility.
     */
    public ChurnPredictionResult predict(
            NewCustomerDto customer)
            throws Exception {

        if (customer == null) {

            throw new IllegalArgumentException(
                    "Customer data cannot be null."
            );
        }

        throw new IllegalArgumentException(
                "New customer prediction is not configured "
                        + "for the current ML feature schema."
        );
    }
}