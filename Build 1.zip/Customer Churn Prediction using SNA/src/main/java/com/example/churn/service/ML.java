package com.example.churn.service;

import com.example.churn.dto.MLModelScore;
import com.example.churn.dto.MLTrainingResult;
import com.example.churn.dto.ModelPredictionDto;

import org.springframework.stereotype.Service;

import smile.classification.Classifier;
import smile.classification.DecisionTree;
import smile.classification.GradientTreeBoost;
import smile.classification.LogisticRegression;
import smile.classification.RandomForest;
import smile.classification.SVM;
import smile.data.DataFrame;
import smile.data.Tuple;
import smile.data.formula.Formula;

import tech.tablesaw.api.Row;
import tech.tablesaw.api.Table;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.Random;

@Service
public class ML {

    /*
     * ============================================================
     * TARGET
     * ============================================================
     */

    private static final String TARGET_COLUMN = "churn";


    /*
     * ============================================================
     * FEATURES
     *
     * IMPORTANT:
     * PredictionService must create the feature vector
     * in exactly this same order.
     *
     * Total = 27 features
     * ============================================================
     */

    private static final String[] FEATURE_NAMES = {

            "seniorCitizen",
            "tenure",
            "monthlyCharges",
            "totalCharges",

            "gender",
            "partner",
            "dependents",
            "phoneService",
            "multipleLines",
            "internetService",
            "onlineSecurity",
            "onlineBackup",
            "deviceProtection",
            "techSupport",
            "streamingTV",
            "streamingMovies",
            "contract",
            "paperlessBilling",
            "paymentMethod",

            "inDegree",
            "outDegree",
            "totalDegree",
            "betweenness",
            "closeness",
            "influence",
            "conformity"
    };


    /*
     * ============================================================
     * MODELS
     * ============================================================
     */

    private GradientTreeBoost gradientBoosting;

    private RandomForest randomForest;

    private DecisionTree decisionTree;

    private LogisticRegression.Binomial logisticRegression;

    private Classifier<double[]> svm;


    /*
     * ============================================================
     * STATUS
     * ============================================================
     */

    private boolean modelTrained = false;

    private int totalRecords;

    private int trainingRecords;

    private int testingRecords;


    /*
     * ============================================================
     * TRAIN ALL FIVE MODELS
     * ============================================================
     */

    public synchronized MLTrainingResult trainAndEvaluate(
            Table finalDataset) {

        if (finalDataset == null) {

            throw new IllegalArgumentException(
                    "Final dataset cannot be null."
            );
        }

        if (finalDataset.rowCount() < 20) {

            throw new IllegalArgumentException(
                    "Not enough records for ML training."
            );
        }

        System.out.println();
        System.out.println("======================================");
        System.out.println("MACHINE LEARNING TRAINING");
        System.out.println("======================================");

        System.out.println(
                "Final dataset rows : "
                        + finalDataset.rowCount()
        );

        System.out.println(
                "Final dataset columns : "
                        + finalDataset.columnNames()
        );


        /*
         * Validate required columns.
         */

        validateColumns(finalDataset);


        /*
         * Convert Tablesaw table into
         * double[][] feature matrix and int[] target.
         */

        DatasetArrays dataset =
                convertTablesawTable(
                        finalDataset
                );


        totalRecords =
                dataset.x.length;


        if (totalRecords < 20) {

            throw new IllegalArgumentException(
                    "Insufficient usable records after preprocessing."
            );
        }


        /*
         * Make sure both classes exist.
         */

        if (!containsBothClasses(dataset.y)) {

            throw new IllegalArgumentException(
                    "The Churn column must contain both "
                            + "0 and 1 classes."
            );
        }


        /*
         * 80% training
         * 20% testing
         */

        SplitData split =
                stratifiedSplit(
                        dataset.x,
                        dataset.y,
                        0.80
                );


        trainingRecords =
                split.xTrain.length;

        testingRecords =
                split.xTest.length;


        System.out.println(
                "Total records   : "
                        + totalRecords
        );

        System.out.println(
                "Training records: "
                        + trainingRecords
        );

        System.out.println(
                "Testing records : "
                        + testingRecords
        );

        System.out.println(
                "Feature count   : "
                        + FEATURE_NAMES.length
        );


        /*
         * ========================================================
         * CREATE SMILE TRAINING DATAFRAME
         * ========================================================
         *
         * IMPORTANT:
         *
         * The feature matrix is double[][].
         *
         * The target MUST be int[][].
         *
         * Do NOT create the target as double[][].
         *
         * This fixes:
         *
         * UnsupportedOperationException
         * BaseVector.toIntArray()
         * ClassLabels.fit()
         *
         */

        DataFrame trainFrame =
                buildDataFrame(
                        split.xTrain,
                        split.yTrain
                );


        Formula formula =
                Formula.lhs(
                        TARGET_COLUMN
                );


        /*
         * ========================================================
         * 1. GRADIENT BOOSTING
         *
         * PRIMARY MODEL
         * ========================================================
         */

        System.out.println();
        System.out.println(
                "Training Gradient Boosting..."
        );

        gradientBoosting =
                GradientTreeBoost.fit(
                        formula,
                        trainFrame
                );


        /*
         * ========================================================
         * 2. RANDOM FOREST
         * ========================================================
         */

        System.out.println(
                "Training Random Forest..."
        );

        randomForest =
                RandomForest.fit(
                        formula,
                        trainFrame
                );


        /*
         * ========================================================
         * 3. DECISION TREE
         * ========================================================
         */

        System.out.println(
                "Training Decision Tree..."
        );

        decisionTree =
                DecisionTree.fit(
                        formula,
                        trainFrame
                );


        /*
         * ========================================================
         * 4. LOGISTIC REGRESSION
         * ========================================================
         */

        System.out.println(
                "Training Logistic Regression..."
        );

        logisticRegression =
                LogisticRegression.binomial(
                        split.xTrain,
                        split.yTrain
                );


        /*
         * ========================================================
         * 5. SVM
         * ========================================================
         */

        System.out.println(
                "Training SVM..."
        );

        Properties svmProperties =
                new Properties();

        svm =
                SVM.fit(
                        split.xTrain,
                        split.yTrain,
                        svmProperties
                );


        /*
         * ========================================================
         * EVALUATION
         * ========================================================
         */

        DataFrame testFrame =
                buildDataFrame(
                        split.xTest,
                        split.yTest
                );


        MLModelScore gradientScore =
                evaluateGradientBoosting(
                        testFrame,
                        split.yTest
                );


        MLModelScore randomForestScore =
                evaluateRandomForest(
                        testFrame,
                        split.yTest
                );


        MLModelScore decisionTreeScore =
                evaluateDecisionTree(
                        testFrame,
                        split.yTest
                );


        MLModelScore logisticScore =
                evaluateLogisticRegression(
                        split.xTest,
                        split.yTest
                );


        MLModelScore svmScore =
                evaluateSVM(
                        split.xTest,
                        split.yTest
                );


        /*
         * Put all model scores into result.
         */

        List<MLModelScore> scores =
                new ArrayList<>();

        scores.add(
                gradientScore
        );

        scores.add(
                randomForestScore
        );

        scores.add(
                decisionTreeScore
        );

        scores.add(
                logisticScore
        );

        scores.add(
                svmScore
        );


        /*
         * Training successful.
         */

        modelTrained = true;


        System.out.println();
        System.out.println(
                "======================================"
        );

        System.out.println(
                "ML TRAINING COMPLETED"
        );

        System.out.println(
                "======================================"
        );


        return new MLTrainingResult(
                totalRecords,
                trainingRecords,
                testingRecords,
                FEATURE_NAMES.length,
                scores
        );
    }


    /*
     * ============================================================
     * PRIMARY PREDICTION
     *
     * Gradient Boosting is the primary model.
     * ============================================================
     */

    public PrimaryPrediction predictWithPrimaryModel(
            double[] features) {

        ensureModelsReady();

        validateFeatureVector(
                features
        );


        DataFrame predictionFrame =
                buildPredictionFrame(
                        features
                );


        Tuple tuple =
                predictionFrame.get(0);


        /*
         * Binary classification:
         *
         * class 0 = No Churn
         * class 1 = Churn
         */

        double[] posterior =
                new double[2];


        int prediction =
                gradientBoosting.predict(
                        tuple,
                        posterior
                );


        double probability = 0.0;


        /*
         * Since our labels are 0 and 1,
         * posterior[1] represents churn probability.
         */

        if (posterior.length > 1) {

            probability =
                    posterior[1];
        }


        probability =
                clamp(
                        probability,
                        0.0,
                        1.0
                );


        String label =
                prediction == 1
                        ? "Churn"
                        : "No Churn";


        return new PrimaryPrediction(
                label,
                probability
        );
    }


    /*
     * ============================================================
     * PREDICT USING ALL FIVE MODELS
     * ============================================================
     */

    public List<ModelPredictionDto> predictAll(
            double[] features) {

        ensureModelsReady();

        validateFeatureVector(
                features
        );


        List<ModelPredictionDto> results =
                new ArrayList<>();


        DataFrame predictionFrame =
                buildPredictionFrame(
                        features
                );


        Tuple tuple =
                predictionFrame.get(0);


        /*
         * ========================================================
         * GRADIENT BOOSTING
         * ========================================================
         */

        double[] gbPosterior =
                new double[2];

        int gbPrediction =
                gradientBoosting.predict(
                        tuple,
                        gbPosterior
                );

        double gbProbability =
                gbPosterior.length > 1
                        ? gbPosterior[1]
                        : 0.0;

        gbProbability =
                clamp(
                        gbProbability,
                        0.0,
                        1.0
                );


        results.add(
                new ModelPredictionDto(
                        "Gradient Boosting",
                        label(gbPrediction),
                        gbProbability
                )
        );


        /*
         * ========================================================
         * RANDOM FOREST
         * ========================================================
         */

        double[] rfPosterior =
                new double[2];

        int rfPrediction =
                randomForest.predict(
                        tuple,
                        rfPosterior
                );

        double rfProbability =
                rfPosterior.length > 1
                        ? rfPosterior[1]
                        : 0.0;

        rfProbability =
                clamp(
                        rfProbability,
                        0.0,
                        1.0
                );


        results.add(
                new ModelPredictionDto(
                        "Random Forest",
                        label(rfPrediction),
                        rfProbability
                )
        );


        /*
         * ========================================================
         * DECISION TREE
         * ========================================================
         */

        int dtPrediction =
                decisionTree.predict(
                        tuple
                );


        results.add(
                new ModelPredictionDto(
                        "Decision Tree",
                        label(dtPrediction),
                        dtPrediction == 1
                                ? 1.0
                                : 0.0
                )
        );


        /*
         * ========================================================
         * LOGISTIC REGRESSION
         * ========================================================
         */

        int lrPrediction =
                logisticRegression.predict(
                        features
                );


        double lrProbability =
                logisticProbability(
                        features
                );


        results.add(
                new ModelPredictionDto(
                        "Logistic Regression",
                        label(lrPrediction),
                        lrProbability
                )
        );


        /*
         * ========================================================
         * SVM
         * ========================================================
         */

        int svmPrediction =
                svm.predict(
                        features
                );


        results.add(
                new ModelPredictionDto(
                        "SVM",
                        label(svmPrediction),
                        svmPrediction == 1
                                ? 1.0
                                : 0.0
                )
        );


        return results;
    }


    /*
     * ============================================================
     * LOGISTIC REGRESSION PROBABILITY
     * ============================================================
     *
     * Smile's Binomial model supports predict(x, posterior).
     */

    private double logisticProbability(
            double[] features) {

        try {

            double[] posterior =
                    new double[2];

            logisticRegression.predict(
                    features,
                    posterior
            );

            if (posterior.length > 1) {

                return clamp(
                        posterior[1],
                        0.0,
                        1.0
                );
            }

        } catch (Exception ignored) {

            /*
             * If probability calculation is not
             * available in the current Smile build,
             * return the class prediction as a
             * safe fallback.
             */
        }


        int prediction =
                logisticRegression.predict(
                        features
                );

        return prediction == 1
                ? 1.0
                : 0.0;
    }


    /*
     * ============================================================
     * TABLESAW -> ARRAYS
     * ============================================================
     */

    private DatasetArrays convertTablesawTable(
            Table table) {

        int rows =
                table.rowCount();

        int columns =
                FEATURE_NAMES.length;


        double[][] x =
                new double[rows][columns];

        int[] y =
                new int[rows];


        for (int i = 0;
             i < rows;
             i++) {

            Row row =
                    table.row(i);


            /*
             * ----------------------------------------------------
             * Numeric features
             * ----------------------------------------------------
             */

            x[i][0] =
                    getDouble(
                            row,
                            "SeniorCitizen"
                    );

            x[i][1] =
                    getDouble(
                            row,
                            "tenure"
                    );

            x[i][2] =
                    getDouble(
                            row,
                            "MonthlyCharges"
                    );

            x[i][3] =
                    getDouble(
                            row,
                            "TotalCharges"
                    );


            /*
             * ----------------------------------------------------
             * Categorical features
             * ----------------------------------------------------
             */

            x[i][4] =
                    encodeGender(
                            getString(
                                    row,
                                    "gender"
                            )
                    );


            x[i][5] =
                    encodeYesNo(
                            getString(
                                    row,
                                    "Partner"
                            )
                    );


            x[i][6] =
                    encodeYesNo(
                            getString(
                                    row,
                                    "Dependents"
                            )
                    );


            x[i][7] =
                    encodeYesNo(
                            getString(
                                    row,
                                    "PhoneService"
                            )
                    );


            x[i][8] =
                    encodeMultipleLines(
                            getString(
                                    row,
                                    "MultipleLines"
                            )
                    );


            x[i][9] =
                    encodeInternetService(
                            getString(
                                    row,
                                    "InternetService"
                            )
                    );


            x[i][10] =
                    encodeYesNo(
                            getString(
                                    row,
                                    "OnlineSecurity"
                            )
                    );


            x[i][11] =
                    encodeYesNo(
                            getString(
                                    row,
                                    "OnlineBackup"
                            )
                    );


            x[i][12] =
                    encodeYesNo(
                            getString(
                                    row,
                                    "DeviceProtection"
                            )
                    );


            x[i][13] =
                    encodeYesNo(
                            getString(
                                    row,
                                    "TechSupport"
                            )
                    );


            x[i][14] =
                    encodeYesNo(
                            getString(
                                    row,
                                    "StreamingTV"
                            )
                    );


            x[i][15] =
                    encodeYesNo(
                            getString(
                                    row,
                                    "StreamingMovies"
                            )
                    );


            x[i][16] =
                    encodeContract(
                            getString(
                                    row,
                                    "Contract"
                            )
                    );


            x[i][17] =
                    encodeYesNo(
                            getString(
                                    row,
                                    "PaperlessBilling"
                            )
                    );


            x[i][18] =
                    encodePaymentMethod(
                            getString(
                                    row,
                                    "PaymentMethod"
                            )
                    );


            /*
             * ----------------------------------------------------
             * SNA FEATURES
             * ----------------------------------------------------
             */

            x[i][19] =
                    getDouble(
                            row,
                            "in_degree"
                    );

            x[i][20] =
                    getDouble(
                            row,
                            "out_degree"
                    );

            x[i][21] =
                    getDouble(
                            row,
                            "total_degree"
                    );

            x[i][22] =
                    getDouble(
                            row,
                            "betweenness"
                    );

            x[i][23] =
                    getDouble(
                            row,
                            "closeness"
                    );

            x[i][24] =
                    getDouble(
                            row,
                            "influence"
                    );

            x[i][25] =
                    getDouble(
                            row,
                            "conformity"
                    );


            /*
             * ----------------------------------------------------
             * TARGET
             * ----------------------------------------------------
             */

            y[i] =
                    encodeChurn(
                            getString(
                                    row,
                                    "Churn"
                            )
                    );
        }


        return new DatasetArrays(
                x,
                y
        );
    }


    /*
     * ============================================================
     * IMPORTANT:
     *
     * The target is created as int[][].
     *
     * NOT double[][].
     *
     * NOT IntVector.
     *
     * NOT new DataFrame(IntVector).
     *
     * This is the fix for the previous
     * UnsupportedOperationException.
     * ============================================================
     */

    private DataFrame buildDataFrame(
            double[][] x,
            int[] y) {

        if (x == null ||
                y == null) {

            throw new IllegalArgumentException(
                    "Feature matrix and target cannot be null."
            );
        }


        if (x.length != y.length) {

            throw new IllegalArgumentException(
                    "Feature row count and target row count "
                            + "must be equal."
            );
        }


        if (x.length == 0) {

            throw new IllegalArgumentException(
                    "Cannot create an empty DataFrame."
            );
        }


        /*
         * Feature columns.
         */

        DataFrame featureFrame =
                DataFrame.of(
                        x,
                        FEATURE_NAMES
                );


        /*
         * TARGET:
         *
         * int[][] guarantees an integer target
         * column in Smile.
         */

        int[][] target =
                new int[y.length][1];


        for (int i = 0;
             i < y.length;
             i++) {

            target[i][0] =
                    y[i];
        }


        DataFrame targetFrame =
                DataFrame.of(
                        target,
                        TARGET_COLUMN
                );


        return featureFrame.merge(
                targetFrame
        );
    }


    /*
     * ============================================================
     * PREDICTION DATAFRAME
     * ============================================================
     */

    private DataFrame buildPredictionFrame(
            double[] features) {

        double[][] x =
                new double[1][FEATURE_NAMES.length];


        System.arraycopy(
                features,
                0,
                x[0],
                0,
                FEATURE_NAMES.length
        );


        /*
         * Dummy target.
         *
         * It is only needed because the
         * Formula contains the target column.
         */

        int[] dummyTarget =
                new int[]{0};


        return buildDataFrame(
                x,
                dummyTarget
        );
    }


    /*
     * ============================================================
     * MODEL EVALUATION
     * ============================================================
     */

    private MLModelScore evaluateGradientBoosting(
            DataFrame testFrame,
            int[] actual) {

        int[] predicted =
                new int[actual.length];


        for (int i = 0;
             i < actual.length;
             i++) {

            predicted[i] =
                    gradientBoosting.predict(
                            testFrame.get(i)
                    );
        }


        return createScore(
                "Gradient Boosting",
                actual,
                predicted
        );
    }


    private MLModelScore evaluateRandomForest(
            DataFrame testFrame,
            int[] actual) {

        int[] predicted =
                new int[actual.length];


        for (int i = 0;
             i < actual.length;
             i++) {

            predicted[i] =
                    randomForest.predict(
                            testFrame.get(i)
                    );
        }


        return createScore(
                "Random Forest",
                actual,
                predicted
        );
    }


    private MLModelScore evaluateDecisionTree(
            DataFrame testFrame,
            int[] actual) {

        int[] predicted =
                new int[actual.length];


        for (int i = 0;
             i < actual.length;
             i++) {

            predicted[i] =
                    decisionTree.predict(
                            testFrame.get(i)
                    );
        }


        return createScore(
                "Decision Tree",
                actual,
                predicted
        );
    }


    private MLModelScore evaluateLogisticRegression(
            double[][] x,
            int[] actual) {

        int[] predicted =
                new int[actual.length];


        for (int i = 0;
             i < actual.length;
             i++) {

            predicted[i] =
                    logisticRegression.predict(
                            x[i]
                    );
        }


        return createScore(
                "Logistic Regression",
                actual,
                predicted
        );
    }


    private MLModelScore evaluateSVM(
            double[][] x,
            int[] actual) {

        int[] predicted =
                new int[actual.length];


        for (int i = 0;
             i < actual.length;
             i++) {

            predicted[i] =
                    svm.predict(
                            x[i]
                    );
        }


        return createScore(
                "SVM",
                actual,
                predicted
        );
    }


    /*
     * ============================================================
     * METRICS
     * ============================================================
     */

    private MLModelScore createScore(
            String algorithm,
            int[] actual,
            int[] predicted) {

        int tp = 0;
        int tn = 0;
        int fp = 0;
        int fn = 0;


        for (int i = 0;
             i < actual.length;
             i++) {

            if (actual[i] == 1 &&
                    predicted[i] == 1) {

                tp++;

            } else if (
                    actual[i] == 0 &&
                    predicted[i] == 0) {

                tn++;

            } else if (
                    actual[i] == 0 &&
                    predicted[i] == 1) {

                fp++;

            } else if (
                    actual[i] == 1 &&
                    predicted[i] == 0) {

                fn++;
            }
        }


        double accuracy =
                safeDivide(
                        tp + tn,
                        actual.length
                );


        double precision =
                safeDivide(
                        tp,
                        tp + fp
                );


        double recall =
                safeDivide(
                        tp,
                        tp + fn
                );


        double f1;


        if (precision + recall == 0.0) {

            f1 = 0.0;

        } else {

            f1 =
                    2.0 *
                    precision *
                    recall /
                    (precision + recall);
        }


        return new MLModelScore(
                algorithm,
                accuracy,
                precision,
                recall,
                f1
        );
    }


    /*
     * ============================================================
     * STRATIFIED SPLIT
     * ============================================================
     */

    private SplitData stratifiedSplit(
            double[][] x,
            int[] y,
            double trainRatio) {

        List<Integer> class0 =
                new ArrayList<>();

        List<Integer> class1 =
                new ArrayList<>();


        for (int i = 0;
             i < y.length;
             i++) {

            if (y[i] == 0) {

                class0.add(i);

            } else {

                class1.add(i);
            }
        }


        Random random =
                new Random(42);


        Collections.shuffle(
                class0,
                random
        );

        Collections.shuffle(
                class1,
                random
        );


        int train0 =
                calculateTrainSize(
                        class0.size(),
                        trainRatio
                );


        int train1 =
                calculateTrainSize(
                        class1.size(),
                        trainRatio
                );


        List<Integer> trainIndices =
                new ArrayList<>();

        List<Integer> testIndices =
                new ArrayList<>();


        for (int i = 0;
             i < class0.size();
             i++) {

            if (i < train0) {

                trainIndices.add(
                        class0.get(i)
                );

            } else {

                testIndices.add(
                        class0.get(i)
                );
            }
        }


        for (int i = 0;
             i < class1.size();
             i++) {

            if (i < train1) {

                trainIndices.add(
                        class1.get(i)
                );

            } else {

                testIndices.add(
                        class1.get(i)
                );
            }
        }


        Collections.shuffle(
                trainIndices,
                random
        );

        Collections.shuffle(
                testIndices,
                random
        );


        double[][] xTrain =
                new double[
                        trainIndices.size()
                ][];


        int[] yTrain =
                new int[
                        trainIndices.size()
                ];


        double[][] xTest =
                new double[
                        testIndices.size()
                ][];


        int[] yTest =
                new int[
                        testIndices.size()
                ];


        for (int i = 0;
             i < trainIndices.size();
             i++) {

            int original =
                    trainIndices.get(i);


            xTrain[i] =
                    x[original].clone();


            yTrain[i] =
                    y[original];
        }


        for (int i = 0;
             i < testIndices.size();
             i++) {

            int original =
                    testIndices.get(i);


            xTest[i] =
                    x[original].clone();


            yTest[i] =
                    y[original];
        }


        return new SplitData(
                xTrain,
                yTrain,
                xTest,
                yTest
        );
    }


    private int calculateTrainSize(
            int size,
            double ratio) {

        int train =
                (int) Math.round(
                        size * ratio
                );


        if (size > 1) {

            train =
                    Math.max(
                            1,
                            Math.min(
                                    size - 1,
                                    train
                            )
                    );
        }


        return train;
    }


    /*
     * ============================================================
     * ENCODING METHODS
     * ============================================================
     */

    private int encodeChurn(
            String value) {

        if (value == null) {
            return 0;
        }

        String v =
                value.trim()
                        .toLowerCase();


        if (v.equals("yes") ||
                v.equals("true") ||
                v.equals("1") ||
                v.equals("churn")) {

            return 1;
        }


        return 0;
    }


    private double encodeGender(
            String value) {

        if (value == null) {
            return 0.0;
        }


        return value.trim()
                .equalsIgnoreCase("female")
                ? 1.0
                : 0.0;
    }


    private double encodeYesNo(
            String value) {

        if (value == null) {
            return 0.0;
        }


        String v =
                value.trim()
                        .toLowerCase();


        if (v.equals("yes") ||
                v.equals("true") ||
                v.equals("1")) {

            return 1.0;
        }


        return 0.0;
    }


    private double encodeMultipleLines(
            String value) {

        if (value == null) {
            return 0.0;
        }


        String v =
                value.trim()
                        .toLowerCase();


        if (v.equals("yes")) {
            return 1.0;
        }


        if (v.contains("no phone")) {
            return 2.0;
        }


        return 0.0;
    }


    private double encodeInternetService(
            String value) {

        if (value == null) {
            return 0.0;
        }


        String v =
                value.trim()
                        .toLowerCase();


        if (v.equals("fiber optic")) {
            return 2.0;
        }


        if (v.equals("dsl")) {
            return 1.0;
        }


        return 0.0;
    }


    private double encodeContract(
            String value) {

        if (value == null) {
            return 0.0;
        }


        String v =
                value.trim()
                        .toLowerCase();


        if (v.equals("one year")) {
            return 1.0;
        }


        if (v.equals("two year")) {
            return 2.0;
        }


        return 0.0;
    }


    private double encodePaymentMethod(
            String value) {

        if (value == null) {
            return 0.0;
        }


        String v =
                value.trim()
                        .toLowerCase();


        if (v.equals(
                "electronic check")) {

            return 0.0;
        }


        if (v.equals(
                "mailed check")) {

            return 1.0;
        }


        if (v.equals(
                "bank transfer (automatic)")) {

            return 2.0;
        }


        if (v.equals(
                "credit card (automatic)")) {

            return 3.0;
        }


        return 0.0;
    }


    /*
     * ============================================================
     * TABLE VALUE HELPERS
     * ============================================================
     */

    private String getString(
            Row row,
            String column) {

        try {

            Object value =
                    row.getObject(
                            column
                    );


            if (value == null) {
                return "";
            }


            return String.valueOf(value)
                    .trim();

        } catch (Exception e) {

            return "";
        }
    }


    private double getDouble(
            Row row,
            String column) {

        try {

            Object value =
                    row.getObject(
                            column
                    );


            if (value == null) {
                return 0.0;
            }


            String text =
                    String.valueOf(value)
                            .trim();


            if (text.isEmpty()) {
                return 0.0;
            }


            return Double.parseDouble(
                    text
            );

        } catch (Exception e) {

            return 0.0;
        }
    }


    /*
     * ============================================================
     * VALIDATE COLUMNS
     * ============================================================
     */

    private void validateColumns(
            Table table) {

        String[] required = {

                "SeniorCitizen",
                "tenure",
                "MonthlyCharges",
                "TotalCharges",

                "gender",
                "Partner",
                "Dependents",
                "PhoneService",
                "MultipleLines",
                "InternetService",
                "OnlineSecurity",
                "OnlineBackup",
                "DeviceProtection",
                "TechSupport",
                "StreamingTV",
                "StreamingMovies",
                "Contract",
                "PaperlessBilling",
                "PaymentMethod",

                "Churn",

                "in_degree",
                "out_degree",
                "total_degree",
                "betweenness",
                "closeness",
                "influence",
                "conformity"
        };


        for (String column :
                required) {

            if (!table.columnNames()
                    .contains(column)) {

                throw new IllegalArgumentException(
                        "Final dataset is missing ML column: "
                                + column
                                + "\nAvailable columns: "
                                + table.columnNames()
                );
            }
        }
    }


    /*
     * ============================================================
     * MODEL STATUS
     * ============================================================
     */

    public boolean isModelTrained() {

        return modelTrained
                && gradientBoosting != null
                && randomForest != null
                && decisionTree != null
                && logisticRegression != null
                && svm != null;
    }


    private void ensureModelsReady() {

        if (!isModelTrained()) {

            throw new IllegalStateException(
                    "ML models have not been trained yet."
            );
        }
    }


    /*
     * ============================================================
     * FEATURE VECTOR VALIDATION
     * ============================================================
     */

    private void validateFeatureVector(
            double[] features) {

        if (features == null) {

            throw new IllegalArgumentException(
                    "Feature vector cannot be null."
            );
        }


        if (features.length
                != FEATURE_NAMES.length) {

            throw new IllegalArgumentException(
                    "Expected "
                            + FEATURE_NAMES.length
                            + " features but received "
                            + features.length
            );
        }


        for (double value :
                features) {

            if (Double.isNaN(value)
                    || Double.isInfinite(value)) {

                throw new IllegalArgumentException(
                        "Feature vector contains "
                                + "NaN or Infinity."
                );
            }
        }
    }


    /*
     * ============================================================
     * CLASS CHECK
     * ============================================================
     */

    private boolean containsBothClasses(
            int[] y) {

        boolean hasZero = false;

        boolean hasOne = false;


        for (int value : y) {

            if (value == 0) {
                hasZero = true;
            }

            if (value == 1) {
                hasOne = true;
            }
        }


        return hasZero && hasOne;
    }


    /*
     * ============================================================
     * LABEL
     * ============================================================
     */

    private String label(
            int prediction) {

        return prediction == 1
                ? "Churn"
                : "No Churn";
    }


    /*
     * ============================================================
     * SAFE DIVISION
     * ============================================================
     */

    private double safeDivide(
            double numerator,
            double denominator) {

        if (denominator == 0.0) {
            return 0.0;
        }


        return numerator / denominator;
    }


    /*
     * ============================================================
     * CLAMP
     * ============================================================
     */

    private double clamp(
            double value,
            double min,
            double max) {

        return Math.max(
                min,
                Math.min(
                        max,
                        value
                )
        );
    }


    /*
     * ============================================================
     * PRIMARY PREDICTION DTO
     * ============================================================
     */

    public static class PrimaryPrediction {

        private final String prediction;

        private final double probability;


        public PrimaryPrediction(
                String prediction,
                double probability) {

            this.prediction =
                    prediction;

            this.probability =
                    probability;
        }


        public String getPrediction() {

            return prediction;
        }


        public double getProbability() {

            return probability;
        }
    }


    /*
     * ============================================================
     * INTERNAL DATASET CLASS
     * ============================================================
     */

    private static class DatasetArrays {

        private final double[][] x;

        private final int[] y;


        private DatasetArrays(
                double[][] x,
                int[] y) {

            this.x = x;

            this.y = y;
        }
    }


    /*
     * ============================================================
     * INTERNAL SPLIT CLASS
     * ============================================================
     */

    private static class SplitData {

        private final double[][] xTrain;

        private final int[] yTrain;

        private final double[][] xTest;

        private final int[] yTest;


        private SplitData(
                double[][] xTrain,
                int[] yTrain,
                double[][] xTest,
                int[] yTest) {

            this.xTrain =
                    xTrain;

            this.yTrain =
                    yTrain;

            this.xTest =
                    xTest;

            this.yTest =
                    yTest;
        }
    }
}