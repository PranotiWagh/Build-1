package com.example.churn.service;

import org.springframework.stereotype.Service;

import tech.tablesaw.api.DoubleColumn;
import tech.tablesaw.api.Row;
import tech.tablesaw.api.Table;

import java.util.HashMap;
import java.util.Map;

@Service
public class FeatureMerging {

    /*
     * ============================================================
     * MERGE CUSTOMER DATA + SNA FEATURES
     * ============================================================
     *
     * Customer CSV:
     *
     *     customerID
     *     9237-HQITU
     *
     * CDR/SNA data:
     *
     *     customer_id
     *     9237
     *
     * Therefore both IDs are normalized before matching.
     *
     * SNA features:
     *
     *     in_degree
     *     out_degree
     *     total_degree
     *     betweenness
     *     closeness
     *     influence
     *     conformity
     *
     * ============================================================
     */

    public Table merge(
            Table customerData,
            Table networkFeatures) {

        if (customerData == null) {

            throw new IllegalArgumentException(
                    "Customer data cannot be null."
            );
        }

        if (!customerData.columnNames()
                .contains("customerID")) {

            throw new IllegalArgumentException(
                    "Customer table does not contain "
                            + "'customerID'."
                            + "\nAvailable columns: "
                            + customerData.columnNames()
            );
        }

        /*
         * ========================================================
         * STEP 1: Create SNA lookup map
         * ========================================================
         *
         * Key:
         *     normalized customer ID
         *
         * Value:
         *     seven SNA values
         */

        Map<String, double[]> snaMap =
                new HashMap<>();

        if (networkFeatures != null
                && networkFeatures.rowCount() > 0) {

            if (!networkFeatures.columnNames()
                    .contains("customer_id")) {

                throw new IllegalArgumentException(
                        "SNA table does not contain "
                                + "'customer_id'."
                                + "\nAvailable columns: "
                                + networkFeatures.columnNames()
                );
            }

            for (int i = 0;
                 i < networkFeatures.rowCount();
                 i++) {

                Row row =
                        networkFeatures.row(i);

                String rawCustomerId =
                        getString(
                                row,
                                "customer_id"
                        );

                String customerId =
                        normalizeId(
                                rawCustomerId
                        );

                if (customerId.isEmpty()) {
                    continue;
                }

                double[] values =
                        new double[] {

                                getDouble(
                                        row,
                                        "in_degree"
                                ),

                                getDouble(
                                        row,
                                        "out_degree"
                                ),

                                getDouble(
                                        row,
                                        "total_degree"
                                ),

                                getDouble(
                                        row,
                                        "betweenness"
                                ),

                                getDouble(
                                        row,
                                        "closeness"
                                ),

                                getDouble(
                                        row,
                                        "influence"
                                ),

                                getDouble(
                                        row,
                                        "conformity"
                                )
                        };

                snaMap.put(
                        customerId,
                        values
                );
            }
        }

        /*
         * ========================================================
         * STEP 2: Create SNA columns
         * ========================================================
         */

        DoubleColumn inDegree =
                DoubleColumn.create(
                        "in_degree"
                );

        DoubleColumn outDegree =
                DoubleColumn.create(
                        "out_degree"
                );

        DoubleColumn totalDegree =
                DoubleColumn.create(
                        "total_degree"
                );

        DoubleColumn betweenness =
                DoubleColumn.create(
                        "betweenness"
                );

        DoubleColumn closeness =
                DoubleColumn.create(
                        "closeness"
                );

        DoubleColumn influence =
                DoubleColumn.create(
                        "influence"
                );

        DoubleColumn conformity =
                DoubleColumn.create(
                        "conformity"
                );

        /*
         * Counter for debugging.
         */
        int matchedCount = 0;
        int unmatchedCount = 0;

        /*
         * ========================================================
         * STEP 3: Match every customer with SNA data
         * ========================================================
         */

        for (int i = 0;
             i < customerData.rowCount();
             i++) {

            Row row =
                    customerData.row(i);

            String rawCustomerId =
                    getString(
                            row,
                            "customerID"
                    );

            String customerId =
                    normalizeId(
                            rawCustomerId
                    );

            double[] values =
                    snaMap.get(
                            customerId
                    );

            /*
             * If customer exists in CDR/SNA data,
             * use its actual SNA values.
             */

            if (values != null) {

                matchedCount++;

            } else {

                /*
                 * Customer has no corresponding CDR node.
                 * In that case the correct default is zero.
                 */

                unmatchedCount++;

                values =
                        new double[] {
                                0.0,
                                0.0,
                                0.0,
                                0.0,
                                0.0,
                                0.0,
                                0.0
                        };
            }

            inDegree.append(
                    values[0]
            );

            outDegree.append(
                    values[1]
            );

            totalDegree.append(
                    values[2]
            );

            betweenness.append(
                    values[3]
            );

            closeness.append(
                    values[4]
            );

            influence.append(
                    values[5]
            );

            conformity.append(
                    values[6]
            );
        }

        /*
         * ========================================================
         * STEP 4: Create final merged table
         * ========================================================
         */

        Table finalDataset =
                customerData.copy();

        finalDataset.addColumns(
                inDegree,
                outDegree,
                totalDegree,
                betweenness,
                closeness,
                influence,
                conformity
        );

        /*
         * ========================================================
         * DEBUG INFORMATION
         * ========================================================
         */

        System.out.println();
        System.out.println(
                "======================================"
        );
        System.out.println(
                "FEATURE MERGING"
        );
        System.out.println(
                "======================================"
        );

        System.out.println(
                "Customer rows : "
                        + customerData.rowCount()
        );

        System.out.println(
                "SNA rows      : "
                        + (
                        networkFeatures == null
                                ? 0
                                : networkFeatures.rowCount()
                )
        );

        System.out.println(
                "Matched SNA customers   : "
                        + matchedCount
        );

        System.out.println(
                "Unmatched customers     : "
                        + unmatchedCount
        );

        System.out.println(
                "Final rows    : "
                        + finalDataset.rowCount()
        );

        System.out.println(
                "Final columns : "
                        + finalDataset.columnNames()
        );

        /*
         * Print one matched SNA example.
         */
        if (matchedCount > 0) {

            System.out.println();
            System.out.println(
                    "SNA matching successful."
            );
        }

        System.out.println(
                "======================================"
        );
        System.out.println();

        return finalDataset;
    }

    /*
     * ============================================================
     * NORMALIZE CUSTOMER / CDR ID
     * ============================================================
     *
     * Examples:
     *
     *     9237-HQITU  -> 9237
     *     9237        -> 9237
     *     "9237"      -> 9237
     *     9237.0      -> 9237
     *
     * This allows:
     *
     *     Customer CSV ID
     *             9237-HQITU
     *
     * to match:
     *
     *     CDR ID
     *             9237
     */

    private String normalizeId(
            String value) {

        if (value == null) {
            return "";
        }

        String id =
                value.trim();

        if (id.isEmpty()) {
            return "";
        }

        /*
         * Remove quotation marks.
         */
        id = id.replace(
                "\"",
                ""
        );

        /*
         * Remove UTF-8 BOM if present.
         */
        id = id.replace(
                "\uFEFF",
                ""
        );

        id = id.trim();

        /*
         * Customer IDs can be:
         *
         *     9237-HQITU
         *
         * Keep only the portion before '-'.
         */

        int dashIndex =
                id.indexOf("-");

        if (dashIndex > 0) {

            id =
                    id.substring(
                            0,
                            dashIndex
                    );
        }

        /*
         * Tablesaw/numeric CSV values may sometimes appear as:
         *
         *     9237.0
         */

        if (id.matches(
                "\\d+\\.0+"
        )) {

            id =
                    id.substring(
                            0,
                            id.indexOf(".")
                    );
        }

        return id.trim();
    }

    /*
     * ============================================================
     * READ STRING SAFELY
     * ============================================================
     */

    private String getString(
            Row row,
            String columnName) {

        try {

            Object value =
                    row.getObject(
                            columnName
                    );

            if (value == null) {
                return "";
            }

            return String.valueOf(
                    value
            ).trim();

        } catch (Exception e) {

            return "";
        }
    }

    /*
     * ============================================================
     * READ DOUBLE SAFELY
     * ============================================================
     */

    private double getDouble(
            Row row,
            String columnName) {

        try {

            Object value =
                    row.getObject(
                            columnName
                    );

            if (value == null) {
                return 0.0;
            }

            /*
             * Tablesaw numeric value.
             */
            if (value instanceof Number) {

                return (
                        (Number) value
                ).doubleValue();
            }

            String text =
                    String.valueOf(
                            value
                    ).trim();

            if (text.isEmpty()) {
                return 0.0;
            }

            return Double.parseDouble(
                    text
            );

        } catch (Exception e) {

            return 0.0;
        }
    }
}