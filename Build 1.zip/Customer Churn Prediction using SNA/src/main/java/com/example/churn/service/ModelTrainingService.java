package com.example.churn.service;

import com.example.churn.dto.MLTrainingResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tech.tablesaw.api.Table;

@Service
public class ModelTrainingService {

    @Autowired
    private DataPreprocessing dataPreprocessing;

    @Autowired
    private SNA sna;

    @Autowired
    private FeatureMerging featureMerging;

    @Autowired
    private ML ml;

    private MLTrainingResult lastTrainingResult;

    public synchronized MLTrainingResult trainModels()
            throws Exception {

        System.out.println();
        System.out.println("======================================");
        System.out.println("COMPLETE ML PIPELINE");
        System.out.println("======================================");

        Table customerData =
                dataPreprocessing.loadAndCleanCustomerData();

        Table cdrData =
                dataPreprocessing.loadAndCleanCDRData();

        Table networkFeatures =
                sna.calculateSNA(cdrData);

        Table finalDataset =
                featureMerging.merge(
                        customerData,
                        networkFeatures
                );

        MLTrainingResult result =
                ml.trainAndEvaluate(finalDataset);

        lastTrainingResult = result;

        return result;
    }

    public MLTrainingResult getTrainingResult() {
        return lastTrainingResult;
    }

    public boolean isTrainingCompleted() {
        return lastTrainingResult != null
                && ml.isModelTrained();
    }
}