package com.example.churn.dto;

import java.util.List;

public class ChurnPredictionResult {

    private String customerId;

    private String finalPrediction;

    private Double churnProbability;

    /*
     * SNA FEATURES
     */
    private double inDegree;
    private double outDegree;
    private double totalDegree;
    private double betweenness;
    private double closeness;
    private double influence;
    private double conformity;

    /*
     * ALL ML MODEL PREDICTIONS
     */
    private List<ModelPredictionDto> modelPredictions;

    public ChurnPredictionResult() {
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getFinalPrediction() {
        return finalPrediction;
    }

    public void setFinalPrediction(String finalPrediction) {
        this.finalPrediction = finalPrediction;
    }

    public Double getChurnProbability() {
        return churnProbability;
    }

    public void setChurnProbability(Double churnProbability) {
        this.churnProbability = churnProbability;
    }

    /*
     * =========================
     * SNA GETTERS / SETTERS
     * =========================
     */

    public double getInDegree() {
        return inDegree;
    }

    public void setInDegree(double inDegree) {
        this.inDegree = inDegree;
    }

    public double getOutDegree() {
        return outDegree;
    }

    public void setOutDegree(double outDegree) {
        this.outDegree = outDegree;
    }

    public double getTotalDegree() {
        return totalDegree;
    }

    public void setTotalDegree(double totalDegree) {
        this.totalDegree = totalDegree;
    }

    public double getBetweenness() {
        return betweenness;
    }

    public void setBetweenness(double betweenness) {
        this.betweenness = betweenness;
    }

    public double getCloseness() {
        return closeness;
    }

    public void setCloseness(double closeness) {
        this.closeness = closeness;
    }

    public double getInfluence() {
        return influence;
    }

    public void setInfluence(double influence) {
        this.influence = influence;
    }

    public double getConformity() {
        return conformity;
    }

    public void setConformity(double conformity) {
        this.conformity = conformity;
    }

    /*
     * =========================
     * ML MODEL PREDICTIONS
     * =========================
     */

    public List<ModelPredictionDto> getModelPredictions() {
        return modelPredictions;
    }

    public void setModelPredictions(
            List<ModelPredictionDto> modelPredictions) {

        this.modelPredictions = modelPredictions;
    }
}