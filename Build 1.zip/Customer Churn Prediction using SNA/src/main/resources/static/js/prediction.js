document.addEventListener(
    "DOMContentLoaded",
    function () {

        if (!requireLogin()) {
            return;
        }


        const params =
            new URLSearchParams(
                window.location.search
            );


        const customerId =
            params.get("customerId");


        if (customerId) {

            const input =
                document.getElementById(
                    "predictionCustomerId"
                );

            if (input) {

                input.value =
                    customerId;

            }

            runPrediction();

        }

    }
);



// =====================================================
// RUN PREDICTION
// =====================================================

async function runPrediction() {

    const input =
        document.getElementById(
            "predictionCustomerId"
        );


    const customerId =
        input.value.trim();


    if (!customerId) {

        showMessage(
            "predictionMessage",
            "Please enter a Customer ID.",
            "error"
        );

        return;

    }


    const button =
        document.getElementById(
            "predictButton"
        );


    setButtonLoading(
        button,
        true,
        "Predicting..."
    );


    showMessage(
        "predictionMessage",
        "Running SNA and Machine Learning prediction...",
        "info"
    );


    try {

        const data =
            await apiGet(
                "/api/prediction/customer/" +
                encodeURIComponent(
                    customerId
                )
            );


        console.log(
            "Prediction response:",
            data
        );


        renderPrediction(data);


        showMessage(
            "predictionMessage",
            "Prediction completed successfully.",
            "success"
        );


    } catch (error) {

        console.error(
            "Prediction error:",
            error
        );


        showMessage(
            "predictionMessage",
            error.message ||
            "Prediction failed.",
            "error"
        );


    } finally {

        setButtonLoading(
            button,
            false
        );

    }

}



// =====================================================
// RENDER COMPLETE PREDICTION
// =====================================================

function renderPrediction(data) {

    const result =
        document.getElementById(
            "predictionResult"
        );


    if (result) {

        result.classList.remove(
            "hidden"
        );

    }



    // =================================================
    // CHURN PROBABILITY
    // =================================================

    const probability =
        percentValue(
            data.churnProbability
        );


    setText(
        "churnProbability",
        probability.toFixed(2) + "%"
    );



    // =================================================
    // FINAL PREDICTION
    // =================================================

    setText(
        "prediction",
        data.finalPrediction ||
        "-"
    );



    // =================================================
    // SNA FEATURES
    // =================================================

    setText(
        "inDegree",
        formatNumber(
            data.inDegree
        )
    );


    setText(
        "outDegree",
        formatNumber(
            data.outDegree
        )
    );


    setText(
        "totalDegree",
        formatNumber(
            data.totalDegree
        )
    );


    setText(
        "betweenness",
        formatNumber(
            data.betweenness
        )
    );


    setText(
        "closeness",
        formatNumber(
            data.closeness
        )
    );


    /*
     * The backend now returns the actual
     * SNA influence value.
     *
     * pageRankScore is kept as a fallback
     * for compatibility with the older DTO.
     */

    const influenceValue =
        data.influence !== null &&
        data.influence !== undefined
            ? data.influence
            : data.pageRankScore;


    setText(
        "influence",
        formatNumber(
            influenceValue
        )
    );


    setText(
        "conformity",
        formatNumber(
            data.conformity
        )
    );



    // =================================================
    // CHURN STATUS
    // =================================================

    const status =
        getChurnStatus(
            data.finalPrediction
        );



    // =================================================
    // GAUGE
    // =================================================

    const gaugeFill =
        document.getElementById(
            "gaugeFill"
        );


    if (gaugeFill) {

        const circumference =
            327;


        let safeProbability =
            probability;


        if (safeProbability < 0) {
            safeProbability = 0;
        }


        if (safeProbability > 100) {
            safeProbability = 100;
        }


        const offset =
            circumference -
            (
                safeProbability /
                100
            ) *
            circumference;


        gaugeFill.style.transition =
            "none";


        gaugeFill.style.strokeDashoffset =
            circumference;


        gaugeFill.style.stroke =
            status === "churn"
                ? "url(#gaugeDanger)"
                : "url(#gaugePrimary)";


        requestAnimationFrame(
            function () {

                gaugeFill.style.transition =
                    "stroke-dashoffset 1.2s ease";


                gaugeFill.style.strokeDashoffset =
                    offset;

            }
        );

    }



    // =================================================
    // RISK BADGE
    // =================================================

    const riskBadge =
        document.getElementById(
            "riskBadge"
        );


    if (riskBadge) {

        riskBadge.classList.remove(
            "hidden"
        );


        if (status === "churn") {

            riskBadge.textContent =
                "High Churn Risk";


            riskBadge.className =
                "risk-badge high";

        } else {

            riskBadge.textContent =
                "Lower Churn Risk";


            riskBadge.className =
                "risk-badge low";

        }

    }



    // =================================================
    // ML MODEL PREDICTIONS
    // =================================================

    renderModelPredictions(
        data.modelPredictions
    );

}



// =====================================================
// RENDER ML MODELS
// =====================================================

function renderModelPredictions(
    predictions
) {

    const table =
        document.getElementById(
            "modelPredictions"
        );


    if (!table) {
        return;
    }


    table.innerHTML = "";



    if (
        !predictions ||
        !Array.isArray(predictions) ||
        predictions.length === 0
    ) {

        const row =
            document.createElement(
                "tr"
            );


        row.innerHTML = `
            <td
                colspan="3"
                class="table-empty">

                No model prediction data available.

            </td>
        `;


        table.appendChild(
            row
        );


        return;

    }



    predictions.forEach(
        function (model) {

            const row =
                document.createElement(
                    "tr"
                );


            const algorithm =
                model.algorithm ||
                model.modelName ||
                model.model ||
                "-";


            const prediction =
                model.prediction ||
                "-";


            const probability =
                model.probability !== null &&
                model.probability !== undefined
                    ? formatPercentage(
                        model.probability
                    )
                    : "-";


            row.innerHTML = `

                <td>
                    ${escapeHtml(
                        algorithm
                    )}
                </td>

                <td>
                    ${predictionBadge(
                        prediction
                    )}
                </td>

                <td>
                    ${probability}
                </td>

            `;


            table.appendChild(
                row
            );

        }
    );

}