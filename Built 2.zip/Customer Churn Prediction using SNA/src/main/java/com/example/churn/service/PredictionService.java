package com.example.churn.service;

import com.example.churn.dto.ChurnPredictionResult;
import com.example.churn.dto.CustomerResponseDto;
import com.example.churn.dto.ModelPredictionDto;
import com.example.churn.dto.NewCustomerDto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PredictionService {

    @Autowired
    private ML ml;

    @Autowired
    private CustomerService customerService;

    @Autowired
    private SNA sna;

    @Autowired
    private ModelTrainingService modelTrainingService;


    /*
     * ============================================================
     * PREDICT
     * ============================================================
     *
     * Predict churn for a supplied customer.
     *
     * The prediction uses:
     *
     * 1. Customer information
     * 2. SNA features
     * 3. Gradient Boosting as primary model
     * 4. All five ML models
     *
     * SNA is NOT recalculated for every prediction.
     * The cached SNA result is reused.
     */
    public ChurnPredictionResult predict(
            NewCustomerDto customer)
            throws Exception {

        if (customer == null) {

            throw new IllegalArgumentException(
                    "Customer data cannot be null."
            );
        }

        if (customer.getCustomerId() == null
                || customer.getCustomerId()
                .trim()
                .isEmpty()) {

            throw new IllegalArgumentException(
                    "Customer ID cannot be empty."
            );
        }


        /*
         * ========================================================
         * STEP 1
         * Make sure ML models and SNA data are ready.
         * ========================================================
         */

        ensurePredictionDataReady();


        /*
         * ========================================================
         * STEP 2
         * Get SNA features from cache.
         * ========================================================
         */

        enrichSNAFeatures(customer);


        /*
         * ========================================================
         * STEP 3
         * Create exactly 26 features.
         * The order MUST match ML.java.
         * ========================================================
         */

        double[] features =
                createFeatureVector(customer);


        /*
         * ========================================================
         * STEP 4
         * Primary model = Gradient Boosting.
         * ========================================================
         */

        ML.PrimaryPrediction primaryPrediction =
                ml.predictWithPrimaryModel(
                        features
                );


        /*
         * ========================================================
         * STEP 5
         * Get predictions from all five models.
         * ========================================================
         */

        List<ModelPredictionDto> modelPredictions =
                ml.predictAll(
                        features
                );


        /*
         * ========================================================
         * STEP 6
         * Build result.
         * ========================================================
         */

        ChurnPredictionResult result =
                new ChurnPredictionResult();


        result.setCustomerId(
                customer.getCustomerId()
        );


        result.setFinalPrediction(
                primaryPrediction.getPrediction()
        );


        result.setChurnProbability(
                primaryPrediction.getProbability()
        );


        /*
         * ========================================================
         * SNA RESULTS
         * ========================================================
         */

        result.setInDegree(
                toDouble(
                        customer.getInDegree()
                )
        );


        result.setOutDegree(
                toDouble(
                        customer.getOutDegree()
                )
        );


        result.setTotalDegree(
                toDouble(
                        customer.getTotalDegree()
                )
        );


        result.setBetweenness(
                toDouble(
                        customer.getBetweenness()
                )
        );


        result.setCloseness(
                toDouble(
                        customer.getCloseness()
                )
        );


        result.setInfluence(
                toDouble(
                        customer.getInfluence()
                )
        );


        result.setConformity(
                toDouble(
                        customer.getConformity()
                )
        );


        /*
         * ========================================================
         * ALL MODEL RESULTS
         * ========================================================
         */

        result.setModelPredictions(
                modelPredictions
        );


        /*
         * ========================================================
         * CONSOLE OUTPUT
         * ========================================================
         */

        System.out.println();
        System.out.println(
                "======================================"
        );

        System.out.println(
                "PREDICTION RESULT"
        );

        System.out.println(
                "======================================"
        );

        System.out.println(
                "Customer ID       : "
                        + customer.getCustomerId()
        );

        System.out.println(
                "Prediction        : "
                        + primaryPrediction.getPrediction()
        );

        System.out.println(
                "Churn Probability : "
                        + primaryPrediction.getProbability()
        );

        System.out.println();

        System.out.println(
                "SNA FEATURES"
        );

        System.out.println(
                "In Degree         : "
                        + customer.getInDegree()
        );

        System.out.println(
                "Out Degree        : "
                        + customer.getOutDegree()
        );

        System.out.println(
                "Total Degree      : "
                        + customer.getTotalDegree()
        );

        System.out.println(
                "Betweenness       : "
                        + customer.getBetweenness()
        );

        System.out.println(
                "Closeness         : "
                        + customer.getCloseness()
        );

        System.out.println(
                "Influence         : "
                        + customer.getInfluence()
        );

        System.out.println(
                "Conformity        : "
                        + customer.getConformity()
        );

        System.out.println(
                "======================================"
        );


        return result;
    }


    /*
     * ============================================================
     * PREDICT EXISTING CUSTOMER
     * ============================================================
     */

    public ChurnPredictionResult
    predictExistingCustomer(
            String customerId)
            throws Exception {

        if (customerId == null
                || customerId.trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Customer ID cannot be empty."
            );
        }


        CustomerResponseDto customer =
                customerService.getCustomer(
                        customerId
                );


        if (customer == null) {

            throw new IllegalArgumentException(
                    "Customer not found: "
                            + customerId
            );
        }


        /*
         * Convert database/customer DTO
         * into prediction DTO.
         */

        NewCustomerDto dto =
                convertToNewCustomerDto(
                        customer
                );


        return predict(dto);
    }


    /*
     * ============================================================
     * ENSURE PREDICTION DATA IS READY
     * ============================================================
     *
     * If the application has just started:
     *
     *     ML models = not trained
     *     SNA cache = not available
     *
     * Then automatically execute:
     *
     * Customer preprocessing
     *        ↓
     * CDR preprocessing
     *        ↓
     * SNA
     *        ↓
     * Feature merging
     *        ↓
     * ML training
     *
     * After that, prediction can continue.
     *
     * IMPORTANT:
     * This happens only when the models/cache are not ready.
     * It does NOT happen for every prediction.
     */
    private synchronized void
    ensurePredictionDataReady()
            throws Exception {

        boolean mlReady =
                ml.isModelTrained();

        boolean snaReady =
                sna.isSnaCalculated();


        /*
         * Everything already available.
         */

        if (mlReady && snaReady) {

            System.out.println(
                    "ML models and SNA cache are already ready."
            );

            return;
        }


        System.out.println();
        System.out.println(
                "======================================"
        );

        System.out.println(
                "AUTOMATIC ML/SNA INITIALIZATION"
        );

        System.out.println(
                "======================================"
        );


        /*
         * Train everything if either ML or SNA
         * is not ready.
         */

        if (!mlReady || !snaReady) {

            System.out.println(
                    "ML ready : "
                            + mlReady
            );

            System.out.println(
                    "SNA ready : "
                            + snaReady
            );

            System.out.println(
                    "Starting complete training pipeline..."
            );


            modelTrainingService.trainModels();


            System.out.println(
                    "Complete training pipeline finished."
            );
        }


        /*
         * Verify.
         */

        if (!ml.isModelTrained()) {

            throw new IllegalStateException(
                    "ML models could not be trained."
            );
        }


        if (!sna.isSnaCalculated()) {

            throw new IllegalStateException(
                    "SNA features could not be calculated."
            );
        }


        System.out.println(
                "ML models ready : "
                        + ml.isModelTrained()
        );

        System.out.println(
                "SNA cache ready : "
                        + sna.isSnaCalculated()
        );

        System.out.println(
                "======================================"
        );
    }


    /*
     * ============================================================
     * GET SNA FEATURES FROM CACHE
     * ============================================================
     *
     * IMPORTANT:
     *
     * DO NOT load the CDR file here.
     *
     * DO NOT call calculateSNA() here.
     *
     * ModelTrainingService already calculated SNA and
     * SNA.java stores the result in its cache.
     */
    private void enrichSNAFeatures(
            NewCustomerDto customer)
            throws Exception {


        /*
         * Get cached network features.
         */

        if (!sna.isSnaCalculated()) {

            throw new IllegalStateException(
                    "SNA features are not available."
            );
        }


        var networkFeatures =
                sna.getCachedSnaFeatures();


        if (networkFeatures == null) {

            throw new IllegalStateException(
                    "Cached SNA features are not available."
            );
        }


        /*
         * Find the selected customer.
         */

        SNA.CustomerSNAResult networkResult =
                sna.getCustomerSNA(
                        networkFeatures,
                        customer.getCustomerId()
                );


        if (networkResult == null) {

            /*
             * Keep zero values if the customer
             * does not exist in the SNA graph.
             */

            customer.setInDegree(0.0);
            customer.setOutDegree(0.0);
            customer.setTotalDegree(0.0);
            customer.setBetweenness(0.0);
            customer.setCloseness(0.0);
            customer.setInfluence(0.0);
            customer.setConformity(0.0);

            System.out.println(
                    "No SNA result found for customer: "
                            + customer.getCustomerId()
            );

            return;
        }


        /*
         * Copy SNA metrics.
         */

        customer.setInDegree(
                networkResult.getInDegree()
        );

        customer.setOutDegree(
                networkResult.getOutDegree()
        );

        customer.setTotalDegree(
                networkResult.getTotalDegree()
        );

        customer.setBetweenness(
                networkResult.getBetweenness()
        );

        customer.setCloseness(
                networkResult.getCloseness()
        );

        customer.setInfluence(
                networkResult.getInfluence()
        );

        customer.setConformity(
                networkResult.getConformity()
        );


        /*
         * Console output.
         */

        System.out.println();
        System.out.println(
                "SNA MATCH FOR CUSTOMER: "
                        + customer.getCustomerId()
        );

        System.out.println(
                "In Degree    : "
                        + customer.getInDegree()
        );

        System.out.println(
                "Out Degree   : "
                        + customer.getOutDegree()
        );

        System.out.println(
                "Total Degree : "
                        + customer.getTotalDegree()
        );

        System.out.println(
                "Betweenness  : "
                        + customer.getBetweenness()
        );

        System.out.println(
                "Closeness    : "
                        + customer.getCloseness()
        );

        System.out.println(
                "Influence    : "
                        + customer.getInfluence()
        );

        System.out.println(
                "Conformity   : "
                        + customer.getConformity()
        );
    }


    /*
     * ============================================================
     * CONVERT EXISTING CUSTOMER DTO
     * ============================================================
     *
     * Historical Churn is intentionally NOT copied because
     * NewCustomerDto does not contain setChurn().
     */
    private NewCustomerDto
    convertToNewCustomerDto(
            CustomerResponseDto customer) {

        NewCustomerDto dto =
                new NewCustomerDto();


        dto.setCustomerId(
                customer.getCustomerId()
        );

        dto.setGender(
                customer.getGender()
        );

        dto.setSeniorCitizen(
                customer.getSeniorCitizen()
        );

        dto.setPartner(
                customer.getPartner()
        );

        dto.setDependents(
                customer.getDependents()
        );

        dto.setTenure(
                customer.getTenure()
        );

        dto.setPhoneService(
                customer.getPhoneService()
        );

        dto.setMultipleLines(
                customer.getMultipleLines()
        );

        dto.setInternetService(
                customer.getInternetService()
        );

        dto.setOnlineSecurity(
                customer.getOnlineSecurity()
        );

        dto.setOnlineBackup(
                customer.getOnlineBackup()
        );

        dto.setDeviceProtection(
                customer.getDeviceProtection()
        );

        dto.setTechSupport(
                customer.getTechSupport()
        );

        dto.setStreamingTV(
                customer.getStreamingTV()
        );

        dto.setStreamingMovies(
                customer.getStreamingMovies()
        );

        dto.setContract(
                customer.getContract()
        );

        dto.setPaperlessBilling(
                customer.getPaperlessBilling()
        );

        dto.setPaymentMethod(
                customer.getPaymentMethod()
        );

        dto.setMonthlyCharges(
                customer.getMonthlyCharges()
        );

        dto.setTotalCharges(
                customer.getTotalCharges()
        );


        /*
         * Existing SNA values.
         *
         * They will be replaced by enrichSNAFeatures()
         * using the current cached SNA data.
         */

        dto.setInDegree(
                customer.getInDegree()
        );

        dto.setOutDegree(
                customer.getOutDegree()
        );

        dto.setTotalDegree(
                customer.getTotalDegree()
        );

        dto.setBetweenness(
                customer.getBetweenness()
        );

        dto.setCloseness(
                customer.getCloseness()
        );

        dto.setInfluence(
                customer.getInfluence()
        );

        dto.setConformity(
                customer.getConformity()
        );


        return dto;
    }


    /*
     * ============================================================
     * CREATE FEATURE VECTOR
     * ============================================================
     *
     * EXACT SAME ORDER AS ML.java
     *
     * 1  seniorCitizen
     * 2  tenure
     * 3  monthlyCharges
     * 4  totalCharges
     * 5  gender
     * 6  partner
     * 7  dependents
     * 8  phoneService
     * 9  multipleLines
     * 10 internetService
     * 11 onlineSecurity
     * 12 onlineBackup
     * 13 deviceProtection
     * 14 techSupport
     * 15 streamingTV
     * 16 streamingMovies
     * 17 contract
     * 18 paperlessBilling
     * 19 paymentMethod
     * 20 inDegree
     * 21 outDegree
     * 22 totalDegree
     * 23 betweenness
     * 24 closeness
     * 25 influence
     * 26 conformity
     */
    private double[] createFeatureVector(
            NewCustomerDto customer) {

        return new double[] {

                /*
                 * 1
                 */
                toDouble(
                        customer.getSeniorCitizen()
                ),

                /*
                 * 2
                 */
                toDouble(
                        customer.getTenure()
                ),

                /*
                 * 3
                 */
                toDouble(
                        customer.getMonthlyCharges()
                ),

                /*
                 * 4
                 */
                toDouble(
                        customer.getTotalCharges()
                ),

                /*
                 * 5
                 */
                encodeGender(
                        customer.getGender()
                ),

                /*
                 * 6
                 */
                encodeYesNo(
                        customer.getPartner()
                ),

                /*
                 * 7
                 */
                encodeYesNo(
                        customer.getDependents()
                ),

                /*
                 * 8
                 */
                encodeYesNo(
                        customer.getPhoneService()
                ),

                /*
                 * 9
                 */
                encodeMultipleLines(
                        customer.getMultipleLines()
                ),

                /*
                 * 10
                 */
                encodeInternetService(
                        customer.getInternetService()
                ),

                /*
                 * 11
                 */
                encodeYesNoUnknown(
                        customer.getOnlineSecurity()
                ),

                /*
                 * 12
                 */
                encodeYesNoUnknown(
                        customer.getOnlineBackup()
                ),

                /*
                 * 13
                 */
                encodeYesNoUnknown(
                        customer.getDeviceProtection()
                ),

                /*
                 * 14
                 */
                encodeYesNoUnknown(
                        customer.getTechSupport()
                ),

                /*
                 * 15
                 */
                encodeYesNoUnknown(
                        customer.getStreamingTV()
                ),

                /*
                 * 16
                 */
                encodeYesNoUnknown(
                        customer.getStreamingMovies()
                ),

                /*
                 * 17
                 */
                encodeContract(
                        customer.getContract()
                ),

                /*
                 * 18
                 */
                encodeYesNo(
                        customer.getPaperlessBilling()
                ),

                /*
                 * 19
                 */
                encodePaymentMethod(
                        customer.getPaymentMethod()
                ),

                /*
                 * 20
                 */
                toDouble(
                        customer.getInDegree()
                ),

                /*
                 * 21
                 */
                toDouble(
                        customer.getOutDegree()
                ),

                /*
                 * 22
                 */
                toDouble(
                        customer.getTotalDegree()
                ),

                /*
                 * 23
                 */
                toDouble(
                        customer.getBetweenness()
                ),

                /*
                 * 24
                 */
                toDouble(
                        customer.getCloseness()
                ),

                /*
                 * 25
                 */
                toDouble(
                        customer.getInfluence()
                ),

                /*
                 * 26
                 */
                toDouble(
                        customer.getConformity()
                )
        };
    }


    /*
     * ============================================================
     * NUMBER CONVERSION
     * ============================================================
     */

    private double toDouble(
            Number value) {

        if (value == null) {
            return 0.0;
        }

        return value.doubleValue();
    }


    /*
     * ============================================================
     * GENDER
     * ============================================================
     */

    private double encodeGender(
            String value) {

        if (value == null) {
            return 0.0;
        }

        return value.trim()
                .equalsIgnoreCase("Male")
                ? 1.0
                : 0.0;
    }


    /*
     * ============================================================
     * YES / NO
     * ============================================================
     */

    private double encodeYesNo(
            String value) {

        if (value == null) {
            return 0.0;
        }

        return value.trim()
                .equalsIgnoreCase("Yes")
                ? 1.0
                : 0.0;
    }


    /*
     * ============================================================
     * YES / NO / UNKNOWN
     * ============================================================
     */

    private double encodeYesNoUnknown(
            String value) {

        if (value == null) {
            return 0.0;
        }

        return value.trim()
                .equalsIgnoreCase("Yes")
                ? 1.0
                : 0.0;
    }


    /*
     * ============================================================
     * MULTIPLE LINES
     * ============================================================
     */

    private double encodeMultipleLines(
            String value) {

        if (value == null) {
            return 0.0;
        }

        return value.trim()
                .equalsIgnoreCase("Yes")
                ? 1.0
                : 0.0;
    }


    /*
     * ============================================================
     * INTERNET SERVICE
     * ============================================================
     *
     * DSL         = 1
     * Fiber optic = 2
     * No          = 0
     */
    private double encodeInternetService(
            String value) {

        if (value == null) {
            return 0.0;
        }

        String normalized =
                value.trim();


        if (normalized.equalsIgnoreCase(
                "DSL")) {

            return 1.0;
        }


        if (normalized.equalsIgnoreCase(
                "Fiber optic")) {

            return 2.0;
        }


        return 0.0;
    }


    /*
     * ============================================================
     * CONTRACT
     * ============================================================
     *
     * Month-to-month = 0
     * One year       = 1
     * Two year       = 2
     */
    private double encodeContract(
            String value) {

        if (value == null) {
            return 0.0;
        }

        String normalized =
                value.trim();


        if (normalized.equalsIgnoreCase(
                "One year")) {

            return 1.0;
        }


        if (normalized.equalsIgnoreCase(
                "Two year")) {

            return 2.0;
        }


        return 0.0;
    }


    /*
     * ============================================================
     * PAYMENT METHOD
     * ============================================================
     *
     * Mailed check                 = 1
     * Bank transfer (automatic)    = 2
     * Credit card (automatic)      = 3
     * Electronic check             = 0
     */
    private double encodePaymentMethod(
            String value) {

        if (value == null) {
            return 0.0;
        }

        String normalized =
                value.trim();


        if (normalized.equalsIgnoreCase(
                "Mailed check")) {

            return 1.0;
        }


        if (normalized.equalsIgnoreCase(
                "Bank transfer (automatic)")) {

            return 2.0;
        }


        if (normalized.equalsIgnoreCase(
                "Credit card (automatic)")) {

            return 3.0;
        }


        return 0.0;
    }
}