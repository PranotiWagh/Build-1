package com.example.churn.controller;

import com.example.churn.dto.LoginRequest;
import com.example.churn.dto.LoginResponse;
import com.example.churn.dto.RegisterRequest;
import com.example.churn.service.AuthenticationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private AuthenticationService authenticationService;

    @PostMapping("/register")
    public ResponseEntity<?> register(
            @RequestBody RegisterRequest request) {

        try {

            LoginResponse response =
                    authenticationService.register(request);

            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException e) {

            return ResponseEntity
                    .badRequest()
                    .body(e.getMessage());

        } catch (Exception e) {

            return ResponseEntity
                    .internalServerError()
                    .body(
                            "Registration failed: "
                                    + e.getMessage()
                    );
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(
            @RequestBody LoginRequest request) {

        try {

            LoginResponse response =
                    authenticationService.login(request);

            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException e) {

            return ResponseEntity
                    .badRequest()
                    .body(e.getMessage());

        } catch (Exception e) {

            return ResponseEntity
                    .internalServerError()
                    .body(
                            "Login failed: "
                                    + e.getMessage()
                    );
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout() {

        try {

            String message =
                    authenticationService.logout();

            return ResponseEntity.ok(message);

        } catch (Exception e) {

            return ResponseEntity
                    .internalServerError()
                    .body(
                            "Logout failed: "
                                    + e.getMessage()
                    );
        }
    }
}