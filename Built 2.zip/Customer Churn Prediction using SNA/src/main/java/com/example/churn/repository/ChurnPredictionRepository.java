package com.example.churn.repository;

import com.example.churn.entity.ChurnPredictionLog;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ChurnPredictionRepository
        extends JpaRepository<ChurnPredictionLog, Long> {

    List<ChurnPredictionLog> findByCustomerId(
            String customerId
    );

    List<ChurnPredictionLog> findByCustomerIdOrderByCreatedAtDesc(
            String customerId
    );
}