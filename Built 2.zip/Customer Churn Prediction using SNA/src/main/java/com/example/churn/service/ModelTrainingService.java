package com.example.churn.service;

import com.example.churn.dto.MLTrainingResult;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tech.tablesaw.api.Table;

@Service
public class ModelTrainingService {

    @Autowired
    private DataPreprocessing dataPreprocessing;

    @Autowired
    private SNA sna;

    @Autowired
    private FeatureMerging featureMerging;

    @Autowired
    private ML ml;

    /*
     * Stores the latest training result.
     */
    private MLTrainingResult lastTrainingResult;


    /*
     * ============================================================
     * TRAIN ALL MODELS
     * ============================================================
     *
     * Complete pipeline:
     *
     * Customer CSV
     *       ↓
     * Customer preprocessing
     *       ↓
     * CDR CSV
     *       ↓
     * CDR preprocessing
     *       ↓
     * SNA calculation
     *       ↓
     * Customer + SNA merge
     *       ↓
     * Train 5 ML models
     *
     * SNA.calculateSNA() also stores the calculated
     * network features inside the SNA service cache.
     *
     * Therefore PredictionService can reuse those
     * features without reading the CDR file again.
     */
    public synchronized MLTrainingResult trainModels()
            throws Exception {

        System.out.println();
        System.out.println("======================================");
        System.out.println("COMPLETE ML PIPELINE");
        System.out.println("======================================");


        /*
         * ========================================================
         * 1. LOAD AND CLEAN CUSTOMER DATA
         * ========================================================
         */

        System.out.println();
        System.out.println("STEP 1: CUSTOMER DATA");

        Table customerData =
                dataPreprocessing
                        .loadAndCleanCustomerData();

        System.out.println(
                "Customer rows after cleaning : "
                        + customerData.rowCount()
        );


        /*
         * ========================================================
         * 2. LOAD AND CLEAN CDR DATA
         * ========================================================
         */

        System.out.println();
        System.out.println("STEP 2: CDR DATA");

        Table cdrData =
                dataPreprocessing
                        .loadAndCleanCDRData();

        System.out.println(
                "CDR rows after cleaning : "
                        + cdrData.rowCount()
        );


        /*
         * ========================================================
         * 3. CALCULATE SNA
         * ========================================================
         *
         * Important:
         *
         * SNA.calculateSNA() now caches the resulting table.
         *
         * The first training call calculates SNA.
         *
         * Later prediction calls reuse the cached table.
         */

        System.out.println();
        System.out.println("STEP 3: SNA");

        Table networkFeatures =
                sna.calculateSNA(
                        cdrData
                );

        if (networkFeatures == null) {

            throw new IllegalStateException(
                    "SNA calculation returned null."
            );
        }

        System.out.println(
                "SNA rows : "
                        + networkFeatures.rowCount()
        );


        /*
         * ========================================================
         * 4. MERGE CUSTOMER DATA + SNA
         * ========================================================
         */

        System.out.println();
        System.out.println("STEP 4: FEATURE MERGING");

        Table finalDataset =
                featureMerging.merge(
                        customerData,
                        networkFeatures
                );

        if (finalDataset == null) {

            throw new IllegalStateException(
                    "Feature merging returned null."
            );
        }

        System.out.println(
                "Final dataset rows : "
                        + finalDataset.rowCount()
        );

        System.out.println(
                "Final dataset columns : "
                        + finalDataset.columnNames()
        );


        /*
         * ========================================================
         * 5. TRAIN AND EVALUATE FIVE MODELS
         * ========================================================
         *
         * Models:
         *
         * 1. Gradient Boosting
         * 2. Random Forest
         * 3. Decision Tree
         * 4. Logistic Regression
         * 5. SVM
         */

        System.out.println();
        System.out.println("STEP 5: MACHINE LEARNING");

        MLTrainingResult result =
                ml.trainAndEvaluate(
                        finalDataset
                );


        /*
         * Store latest training result.
         */

        lastTrainingResult =
                result;


        /*
         * ========================================================
         * TRAINING COMPLETED
         * ========================================================
         */

        System.out.println();
        System.out.println("======================================");
        System.out.println("ML TRAINING COMPLETED");
        System.out.println("======================================");

        System.out.println(
                "ML models trained : "
                        + ml.isModelTrained()
        );

        System.out.println(
                "SNA cache available : "
                        + sna.isSnaCalculated()
        );


        return result;
    }


    /*
     * ============================================================
     * GET LAST TRAINING RESULT
     * ============================================================
     */

    public MLTrainingResult getTrainingResult() {

        return lastTrainingResult;
    }


    /*
     * ============================================================
     * CHECK TRAINING STATUS
     * ============================================================
     */

    public boolean isTrainingCompleted() {

        return lastTrainingResult != null
                && ml.isModelTrained();
    }
}