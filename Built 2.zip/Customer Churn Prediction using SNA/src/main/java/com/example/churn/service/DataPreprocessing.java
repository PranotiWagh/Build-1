package com.example.churn.service;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import tech.tablesaw.api.Table;
import tech.tablesaw.io.csv.CsvReadOptions;

import java.io.InputStream;

@Service
public class DataPreprocessing {

    public Table loadAndCleanCustomerData()
            throws Exception {

        System.out.println();
        System.out.println(
                "======================================"
        );
        System.out.println(
                "CUSTOMER DATA PREPROCESSING"
        );
        System.out.println(
                "======================================"
        );

        ClassPathResource resource =
                new ClassPathResource(
                        "models/Telecom Customer Data.csv"
                );

        if (!resource.exists()) {

            throw new IllegalArgumentException(
                    "Telecom Customer Data.csv not found inside "
                            + "src/main/resources/models/"
            );
        }

        try (InputStream inputStream =
                     resource.getInputStream()) {

            Table customerTable =
                    Table.read()
                            .csv(
                                    CsvReadOptions
                                            .builder(inputStream)
                                            .build()
                            );

            cleanColumnNames(customerTable);

            System.out.println(
                    "Original Rows    : "
                            + customerTable.rowCount()
            );

            System.out.println(
                    "Original Columns : "
                            + customerTable.columnCount()
            );

            System.out.println(
                    "Customer Columns : "
                            + customerTable.columnNames()
            );

            validateCustomerColumns(
                    customerTable
            );

            Table cleanTable =
                    customerTable
                            .dropRowsWithMissingValues()
                            .dropDuplicateRows();

            System.out.println(
                    "After Cleaning Rows    : "
                            + cleanTable.rowCount()
            );

            System.out.println(
                    "After Cleaning Columns : "
                            + cleanTable.columnCount()
            );

            return cleanTable;
        }
    }

    public Table loadAndCleanCDRData()
            throws Exception {

        System.out.println();
        System.out.println(
                "======================================"
        );
        System.out.println(
                "CDR DATA PREPROCESSING"
        );
        System.out.println(
                "======================================"
        );

        ClassPathResource resource =
                new ClassPathResource(
                        "models/CDR-Call-Details.csv"
                );

        if (!resource.exists()) {

            throw new IllegalArgumentException(
                    "CDR-Call-Details.csv not found inside "
                            + "src/main/resources/models/"
            );
        }

        try (InputStream inputStream =
                     resource.getInputStream()) {

            Table cdrTable =
                    Table.read()
                            .csv(
                                    CsvReadOptions
                                            .builder(inputStream)
                                            .build()
                            );

            cleanColumnNames(cdrTable);

            System.out.println(
                    "Original Rows    : "
                            + cdrTable.rowCount()
            );

            System.out.println(
                    "Original Columns : "
                            + cdrTable.columnCount()
            );

            System.out.println(
                    "CDR Columns : "
                            + cdrTable.columnNames()
            );

            validateCDRColumns(cdrTable);

            System.out.println(
                    "Caller id type : "
                            + cdrTable
                            .column("Caller id")
                            .type()
            );

            System.out.println(
                    "Receiver id type : "
                            + cdrTable
                            .column("Receiver id")
                            .type()
            );

            Table cleanCDR =
                    cdrTable
                            .dropRowsWithMissingValues()
                            .dropDuplicateRows();

            System.out.println(
                    "After Cleaning Rows    : "
                            + cleanCDR.rowCount()
            );

            System.out.println(
                    "After Cleaning Columns : "
                            + cleanCDR.columnCount()
            );

            return cleanCDR;
        }
    }

    private void cleanColumnNames(Table table) {

        String[] names =
                table.columnNames()
                        .toArray(new String[0]);

        for (String originalName : names) {

            String cleanedName =
                    originalName
                            .trim()
                            .replaceAll(
                                    "^\\uFEFF",
                                    ""
                            )
                            .replaceAll(
                                    "^\"|\"$",
                                    ""
                            );

            if (!originalName.equals(cleanedName)) {

                table.column(originalName)
                        .setName(cleanedName);
            }
        }
    }

    private void validateCustomerColumns(
            Table table) {

        String[] requiredColumns = {

                "customerID",
                "gender",
                "SeniorCitizen",
                "Partner",
                "Dependents",
                "tenure",
                "PhoneService",
                "MultipleLines",
                "InternetService",
                "OnlineSecurity",
                "OnlineBackup",
                "DeviceProtection",
                "TechSupport",
                "StreamingTV",
                "StreamingMovies",
                "Contract",
                "PaperlessBilling",
                "PaymentMethod",
                "MonthlyCharges",
                "TotalCharges",
                "Churn"
        };

        for (String required :
                requiredColumns) {

            if (!table.columnNames()
                    .contains(required)) {

                throw new IllegalArgumentException(
                        "Customer CSV is missing required "
                                + "column: "
                                + required
                                + "\nAvailable columns: "
                                + table.columnNames()
                );
            }
        }
    }

    private void validateCDRColumns(
            Table table) {

        String[] requiredColumns = {
                "Caller id",
                "Receiver id"
        };

        for (String required :
                requiredColumns) {

            if (!table.columnNames()
                    .contains(required)) {

                throw new IllegalArgumentException(
                        "CDR CSV is missing required "
                                + "column: "
                                + required
                                + "\nAvailable columns: "
                                + table.columnNames()
                );
            }
        }
    }
}