package com.example.churn.controller;

import com.example.churn.entity.ChurnPredictionLog;
import com.example.churn.service.DashboardService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
@CrossOrigin(origins = "*")
public class DashboardController {

    @Autowired
    private DashboardService dashboardService;

    @GetMapping("/summary")
    public ResponseEntity<?> getDashboardSummary() {

        try {

            Map<String, Object> dashboard =
                    dashboardService.getDashboardData();

            return ResponseEntity.ok(dashboard);

        } catch (Exception e) {

            return ResponseEntity
                    .internalServerError()
                    .body(
                            "Unable to load dashboard: "
                                    + e.getMessage()
                    );
        }
    }

    @GetMapping("/history")
    public ResponseEntity<?> getPredictionHistory() {

        try {

            List<ChurnPredictionLog> history =
                    dashboardService
                            .getPredictionHistory();

            return ResponseEntity.ok(history);

        } catch (Exception e) {

            return ResponseEntity
                    .internalServerError()
                    .body(
                            "Unable to load prediction history: "
                                    + e.getMessage()
                    );
        }
    }

    @GetMapping("/history/{customerId}")
    public ResponseEntity<?> getCustomerHistory(
            @PathVariable String customerId) {

        try {

            List<ChurnPredictionLog> history =
                    dashboardService
                            .getCustomerPredictionHistory(
                                    customerId
                            );

            return ResponseEntity.ok(history);

        } catch (Exception e) {

            return ResponseEntity
                    .internalServerError()
                    .body(
                            "Unable to load customer history: "
                                    + e.getMessage()
                    );
        }
    }
}