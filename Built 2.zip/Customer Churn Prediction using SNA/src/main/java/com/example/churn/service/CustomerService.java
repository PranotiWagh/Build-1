package com.example.churn.service;

import com.example.churn.dto.CustomerResponseDto;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import tech.tablesaw.api.Row;
import tech.tablesaw.api.Table;
import tech.tablesaw.io.csv.CsvReadOptions;

import java.io.InputStream;

@Service
public class CustomerService {

    private static final String CUSTOMER_FILE =
            "models/Telecom Customer Data.csv";

    /**
     * Returns one customer from the customer CSV.
     */
    public CustomerResponseDto getCustomer(
            String customerId) throws Exception {

        if (customerId == null
                || customerId.trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Customer ID cannot be empty."
            );
        }

        String targetId =
                customerId.trim();

        Table table =
                loadCustomerTable();

        for (int i = 0;
             i < table.rowCount();
             i++) {

            Row row =
                    table.row(i);

            String currentId =
                    stringValue(
                            row.getObject("customerID")
                    );

            if (targetId.equalsIgnoreCase(
                    currentId)) {

                return convertToDto(row);
            }
        }

        throw new IllegalArgumentException(
                "Customer not found: " + customerId
        );
    }

    /**
     * Checks whether a customer exists.
     */
    public boolean customerExists(
            String customerId) throws Exception {

        if (customerId == null
                || customerId.trim().isEmpty()) {

            return false;
        }

        String targetId =
                customerId.trim();

        Table table =
                loadCustomerTable();

        for (int i = 0;
             i < table.rowCount();
             i++) {

            Row row =
                    table.row(i);

            String currentId =
                    stringValue(
                            row.getObject("customerID")
                    );

            if (targetId.equalsIgnoreCase(
                    currentId)) {

                return true;
            }
        }

        return false;
    }

    private Table loadCustomerTable()
            throws Exception {

        ClassPathResource resource =
                new ClassPathResource(
                        CUSTOMER_FILE
                );

        if (!resource.exists()) {

            throw new IllegalArgumentException(
                    "Telecom Customer Data.csv not found inside "
                            + "src/main/resources/models/"
            );
        }

        try (InputStream inputStream =
                     resource.getInputStream()) {

            Table table =
                    Table.read()
                            .csv(
                                    CsvReadOptions
                                            .builder(
                                                    inputStream
                                            )
                                            .build()
                            );

            cleanColumnNames(table);

            return table;
        }
    }

    private CustomerResponseDto convertToDto(
            Row row) {

        CustomerResponseDto dto =
                new CustomerResponseDto();

        dto.setCustomerId(
                stringValue(
                        row.getObject("customerID")
                )
        );

        dto.setGender(
                stringValue(
                        row.getObject("gender")
                )
        );

        /*
         * IMPORTANT:
         *
         * Use intValue() instead of casting
         * a double directly to int.
         *
         * This fixes:
         *
         * possible lossy conversion from double to int
         */
        dto.setSeniorCitizen(
                intValue(
                        row.getObject("SeniorCitizen")
                )
        );

        dto.setPartner(
                stringValue(
                        row.getObject("Partner")
                )
        );

        dto.setDependents(
                stringValue(
                        row.getObject("Dependents")
                )
        );

        dto.setTenure(
                intValue(
                        row.getObject("tenure")
                )
        );

        dto.setPhoneService(
                stringValue(
                        row.getObject("PhoneService")
                )
        );

        dto.setMultipleLines(
                stringValue(
                        row.getObject("MultipleLines")
                )
        );

        dto.setInternetService(
                stringValue(
                        row.getObject("InternetService")
                )
        );

        dto.setOnlineSecurity(
                stringValue(
                        row.getObject("OnlineSecurity")
                )
        );

        dto.setOnlineBackup(
                stringValue(
                        row.getObject("OnlineBackup")
                )
        );

        dto.setDeviceProtection(
                stringValue(
                        row.getObject("DeviceProtection")
                )
        );

        dto.setTechSupport(
                stringValue(
                        row.getObject("TechSupport")
                )
        );

        dto.setStreamingTV(
                stringValue(
                        row.getObject("StreamingTV")
                )
        );

        dto.setStreamingMovies(
                stringValue(
                        row.getObject("StreamingMovies")
                )
        );

        dto.setContract(
                stringValue(
                        row.getObject("Contract")
                )
        );

        dto.setPaperlessBilling(
                stringValue(
                        row.getObject("PaperlessBilling")
                )
        );

        dto.setPaymentMethod(
                stringValue(
                        row.getObject("PaymentMethod")
                )
        );

        dto.setMonthlyCharges(
                doubleValue(
                        row.getObject("MonthlyCharges")
                )
        );

        dto.setTotalCharges(
                doubleValue(
                        row.getObject("TotalCharges")
                )
        );

        /*
         * Churn is historical information.
         * SNA values are not stored in the customer CSV,
         * therefore the lookup service initializes them
         * to zero.
         *
         * PredictionService can use the merged SNA data
         * when the complete pipeline is used.
         */
        dto.setInDegree(0.0);
        dto.setOutDegree(0.0);
        dto.setTotalDegree(0.0);
        dto.setBetweenness(0.0);
        dto.setCloseness(0.0);
        dto.setInfluence(0.0);
        dto.setConformity(0.0);

        return dto;
    }

    private int intValue(
            Object value) {

        if (value == null) {
            return 0;
        }

        if (value instanceof Number) {

            return ((Number) value)
                    .intValue();
        }

        String text =
                value.toString().trim();

        if (text.isEmpty()) {
            return 0;
        }

        try {

            return Integer.parseInt(text);

        } catch (NumberFormatException e) {

            try {

                return (int) Double.parseDouble(
                        text
                );

            } catch (NumberFormatException ignored) {

                return 0;
            }
        }
    }

    private double doubleValue(
            Object value) {

        if (value == null) {
            return 0.0;
        }

        if (value instanceof Number) {

            return ((Number) value)
                    .doubleValue();
        }

        String text =
                value.toString().trim();

        if (text.isEmpty()) {
            return 0.0;
        }

        try {

            return Double.parseDouble(text);

        } catch (NumberFormatException e) {

            return 0.0;
        }
    }

    private String stringValue(
            Object value) {

        if (value == null) {
            return null;
        }

        return value.toString().trim();
    }

    private void cleanColumnNames(
            Table table) {

        String[] names =
                table.columnNames()
                        .toArray(
                                new String[0]
                        );

        for (String originalName : names) {

            String cleanedName =
                    originalName
                            .trim()
                            .replaceAll(
                                    "^\\uFEFF",
                                    ""
                            )
                            .replaceAll(
                                    "^\"|\"$",
                                    ""
                            );

            if (!originalName.equals(
                    cleanedName)) {

                table.column(
                        originalName
                ).setName(
                        cleanedName
                );
            }
        }
    }
}