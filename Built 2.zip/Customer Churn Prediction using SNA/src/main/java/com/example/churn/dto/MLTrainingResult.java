package com.example.churn.dto;

import java.util.List;

public class MLTrainingResult {

    private int totalRecords;

    private int trainingRecords;

    private int testingRecords;

    private int featureCount;

    private List<MLModelScore> models;

    public MLTrainingResult() {
    }

    public MLTrainingResult(
            int totalRecords,
            int trainingRecords,
            int testingRecords,
            int featureCount,
            List<MLModelScore> models) {

        this.totalRecords = totalRecords;
        this.trainingRecords = trainingRecords;
        this.testingRecords = testingRecords;
        this.featureCount = featureCount;
        this.models = models;
    }

    public int getTotalRecords() {
        return totalRecords;
    }

    public void setTotalRecords(int totalRecords) {
        this.totalRecords = totalRecords;
    }

    public int getTrainingRecords() {
        return trainingRecords;
    }

    public void setTrainingRecords(int trainingRecords) {
        this.trainingRecords = trainingRecords;
    }

    public int getTestingRecords() {
        return testingRecords;
    }

    public void setTestingRecords(int testingRecords) {
        this.testingRecords = testingRecords;
    }

    public int getFeatureCount() {
        return featureCount;
    }

    public void setFeatureCount(int featureCount) {
        this.featureCount = featureCount;
    }

    public List<MLModelScore> getModels() {
        return models;
    }

    public void setModels(List<MLModelScore> models) {
        this.models = models;
    }
}