package com.example.churn.service;

import com.example.churn.dto.LoginRequest;
import com.example.churn.dto.LoginResponse;
import com.example.churn.dto.RegisterRequest;
import com.example.churn.entity.User;
import com.example.churn.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthenticationService {

    @Autowired
    private UserRepository userRepository;

    /**
     * Register a new user.
     */
    public LoginResponse register(
            RegisterRequest request) {

        if (request == null) {

            throw new IllegalArgumentException(
                    "Registration data cannot be null."
            );
        }

        if (request.getName() == null
                || request.getName()
                .trim()
                .isEmpty()) {

            throw new IllegalArgumentException(
                    "Name cannot be empty."
            );
        }

        if (request.getEmail() == null
                || request.getEmail()
                .trim()
                .isEmpty()) {

            throw new IllegalArgumentException(
                    "Email cannot be empty."
            );
        }

        if (request.getPassword() == null
                || request.getPassword()
                .trim()
                .isEmpty()) {

            throw new IllegalArgumentException(
                    "Password cannot be empty."
            );
        }

        String email =
                request.getEmail()
                        .trim()
                        .toLowerCase();

        if (userRepository.existsByEmail(email)) {

            throw new IllegalArgumentException(
                    "An account with this email already exists."
            );
        }

        User user =
                new User();

        user.setName(
                request.getName().trim()
        );

        user.setEmail(
                email
        );

        user.setPassword(
                request.getPassword()
        );

        User savedUser =
                userRepository.save(user);

        return new LoginResponse(
                true,
                "Registration successful.",
                savedUser.getId(),
                savedUser.getName(),
                savedUser.getEmail()
        );
    }

    /**
     * Login an existing user.
     */
    public LoginResponse login(
            LoginRequest request) {

        if (request == null) {

            throw new IllegalArgumentException(
                    "Login data cannot be null."
            );
        }

        if (request.getEmail() == null
                || request.getEmail()
                .trim()
                .isEmpty()) {

            throw new IllegalArgumentException(
                    "Email cannot be empty."
            );
        }

        if (request.getPassword() == null
                || request.getPassword()
                .trim()
                .isEmpty()) {

            throw new IllegalArgumentException(
                    "Password cannot be empty."
            );
        }

        String email =
                request.getEmail()
                        .trim()
                        .toLowerCase();

        User user =
                userRepository
                        .findByEmail(email)
                        .orElseThrow(
                                () ->
                                        new IllegalArgumentException(
                                                "Invalid email or password."
                                        )
                        );

        if (!user.getPassword()
                .equals(
                        request.getPassword()
                )) {

            throw new IllegalArgumentException(
                    "Invalid email or password."
            );
        }

        return new LoginResponse(
                true,
                "Login successful.",
                user.getId(),
                user.getName(),
                user.getEmail()
        );
    }

    /**
     * Simple logout endpoint.
     *
     * Since this application currently does not
     * use server-side sessions/JWT, there is no
     * server token to invalidate.
     */
    public String logout() {

        return "Logout successful.";
    }
}