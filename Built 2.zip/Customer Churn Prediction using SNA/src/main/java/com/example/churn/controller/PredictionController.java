package com.example.churn.controller;

import com.example.churn.dto.ChurnPredictionResult;
import com.example.churn.dto.NewCustomerDto;
import com.example.churn.service.PredictionService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/prediction")
@CrossOrigin(origins = "*")
public class PredictionController {

    @Autowired
    private PredictionService predictionService;


    /*
     * PREDICT A CUSTOMER FROM INPUT DATA
     *
     * POST /api/prediction/predict
     */
    @PostMapping("/predict")
    public ResponseEntity<?> predict(
            @RequestBody NewCustomerDto customer) {

        try {

            ChurnPredictionResult result =
                    predictionService.predict(
                            customer
                    );

            return ResponseEntity.ok(result);

        } catch (IllegalArgumentException e) {

            return ResponseEntity
                    .badRequest()
                    .body(e.getMessage());

        } catch (IllegalStateException e) {

            return ResponseEntity
                    .status(409)
                    .body(e.getMessage());

        } catch (Exception e) {

            e.printStackTrace();

            String message =
                    e.getClass().getSimpleName()
                            + ": "
                            + (e.getMessage() == null
                            ? "No exception message. Check the server console."
                            : e.getMessage());

            return ResponseEntity
                    .internalServerError()
                    .body(
                            "Prediction failed: "
                                    + message
                    );
        }
    }


    /*
     * PREDICT EXISTING CUSTOMER
     *
     * GET /api/prediction/customer/{customerId}
     *
     * Example:
     * GET /api/prediction/customer/7590-VHVEG
     */
    @GetMapping("/customer/{customerId}")
    public ResponseEntity<?> predictExistingCustomer(
            @PathVariable String customerId) {

        try {

            ChurnPredictionResult result =
                    predictionService
                            .predictExistingCustomer(
                                    customerId
                            );

            return ResponseEntity.ok(result);

        } catch (IllegalArgumentException e) {

            return ResponseEntity
                    .badRequest()
                    .body(e.getMessage());

        } catch (IllegalStateException e) {

            return ResponseEntity
                    .status(409)
                    .body(e.getMessage());

        } catch (Exception e) {

            e.printStackTrace();

            String message =
                    e.getClass().getSimpleName()
                            + ": "
                            + (e.getMessage() == null
                            ? "No exception message. Check the server console."
                            : e.getMessage());

            return ResponseEntity
                    .internalServerError()
                    .body(
                            "Prediction failed: "
                                    + message
                    );
        }
    }
}