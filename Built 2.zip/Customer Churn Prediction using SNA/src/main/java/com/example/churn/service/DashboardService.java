package com.example.churn.service;

import com.example.churn.entity.ChurnPredictionLog;
import com.example.churn.repository.ChurnPredictionRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class DashboardService {

    @Autowired
    private ChurnPredictionRepository predictionRepository;

    public Map<String, Object> getDashboardData() {

        List<ChurnPredictionLog> predictions =
                predictionRepository.findAll();

        int totalPredictions =
                predictions.size();

        int churnCustomers = 0;

        int nonChurnCustomers = 0;

        double totalProbability = 0.0;

        for (ChurnPredictionLog prediction : predictions) {

            if ("Churn".equalsIgnoreCase(
                    prediction.getPrediction())) {

                churnCustomers++;

            } else {

                nonChurnCustomers++;
            }

            totalProbability +=
                    prediction.getChurnProbability();
        }

        double averageProbability =
                totalPredictions == 0
                        ? 0.0
                        : totalProbability /
                          totalPredictions;

        Map<String, Object> dashboard =
                new HashMap<>();

        dashboard.put(
                "totalPredictions",
                totalPredictions
        );

        dashboard.put(
                "churnCustomers",
                churnCustomers
        );

        dashboard.put(
                "nonChurnCustomers",
                nonChurnCustomers
        );

        dashboard.put(
                "averageChurnProbability",
                averageProbability
        );

        return dashboard;
    }

    public List<ChurnPredictionLog> getPredictionHistory() {

        return predictionRepository.findAll();
    }

    public List<ChurnPredictionLog>
    getCustomerPredictionHistory(String customerId) {

        return predictionRepository
                .findByCustomerIdOrderByCreatedAtDesc(
                        customerId
                );
    }
}