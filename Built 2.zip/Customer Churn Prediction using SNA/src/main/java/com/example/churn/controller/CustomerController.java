package com.example.churn.controller;

import com.example.churn.dto.CustomerResponseDto;
import com.example.churn.service.CustomerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/customer")
@CrossOrigin(origins = "*")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    /*
     * GET CUSTOMER BY CUSTOMER ID
     *
     * Example:
     * GET /api/customer/7590-VHVEG
     */
    @GetMapping("/{customerId}")
    public ResponseEntity<?> getCustomer(
            @PathVariable String customerId) {

        try {

            CustomerResponseDto customer =
                    customerService.getCustomer(
                            customerId
                    );

            return ResponseEntity.ok(customer);

        } catch (IllegalArgumentException e) {

            return ResponseEntity
                    .badRequest()
                    .body(e.getMessage());

        } catch (Exception e) {

            return ResponseEntity
                    .internalServerError()
                    .body(
                            "Unable to retrieve customer: "
                                    + e.getMessage()
                    );
        }
    }

    /*
     * CHECK WHETHER CUSTOMER EXISTS
     *
     * Example:
     * GET /api/customer/exists/7590-VHVEG
     */
    @GetMapping("/exists/{customerId}")
    public ResponseEntity<?> customerExists(
            @PathVariable String customerId) {

        try {

            boolean exists =
                    customerService.customerExists(
                            customerId
                    );

            return ResponseEntity.ok(exists);

        } catch (Exception e) {

            return ResponseEntity
                    .internalServerError()
                    .body(
                            "Unable to check customer: "
                                    + e.getMessage()
                    );
        }
    }
}