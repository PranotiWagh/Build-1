package com.example.churn.controller;

import com.example.churn.service.DataPreprocessing;
import com.example.churn.service.SNA;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import tech.tablesaw.api.Table;

@RestController
@RequestMapping("/api/sna")
@CrossOrigin(origins = "*")
public class SNAController {

    @Autowired
    private DataPreprocessing dataPreprocessing;

    @Autowired
    private SNA sna;

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<?> getCustomerSNA(
            @PathVariable String customerId) {

        try {

            if (customerId == null ||
                    customerId.trim().isEmpty()) {

                return ResponseEntity
                        .badRequest()
                        .body(
                                "Customer ID cannot be empty."
                        );
            }

            Table cdrData =
                    dataPreprocessing
                            .loadAndCleanCDRData();

            Table networkFeatures =
                    sna.calculateSNA(cdrData);

            SNA.CustomerSNAResult result =
                    sna.getCustomerSNA(
                            networkFeatures,
                            customerId
                    );

            if (result == null) {

                return ResponseEntity
                        .status(404)
                        .body(
                                "No SNA information found "
                                        + "for customer: "
                                        + customerId
                        );
            }

            return ResponseEntity.ok(result);

        } catch (Exception e) {

            return ResponseEntity
                    .internalServerError()
                    .body(
                            "Unable to calculate SNA: "
                                    + e.getMessage()
                    );
        }
    }

    @GetMapping("/all")
    public ResponseEntity<?> calculateAllSNA() {

        try {

            Table cdrData =
                    dataPreprocessing
                            .loadAndCleanCDRData();

            Table networkFeatures =
                    sna.calculateSNA(cdrData);

            return ResponseEntity.ok(
                    networkFeatures.toString()
            );

        } catch (Exception e) {

            return ResponseEntity
                    .internalServerError()
                    .body(
                            "Unable to calculate SNA: "
                                    + e.getMessage()
                    );
        }
    }
}