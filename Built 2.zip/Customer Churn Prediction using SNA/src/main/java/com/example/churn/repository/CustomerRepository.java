package com.example.churn.repository;

import com.example.churn.entity.Customer;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CustomerRepository
        extends JpaRepository<Customer, Long> {

    Optional<Customer> findByCustomerId(
            String customerId
    );

    boolean existsByCustomerId(
            String customerId
    );

    Optional<Customer> findByEmail(
            String email
    );

    boolean existsByEmail(
            String email
    );
}