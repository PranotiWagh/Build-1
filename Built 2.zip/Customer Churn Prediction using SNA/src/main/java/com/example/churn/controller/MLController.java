package com.example.churn.controller;

import com.example.churn.dto.MLTrainingResult;
import com.example.churn.service.ModelTrainingService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/ml")
@CrossOrigin(origins = "*")
public class MLController {

    @Autowired
    private ModelTrainingService modelTrainingService;

    @GetMapping("/train")
    public ResponseEntity<?> trainModels() {

        try {

            MLTrainingResult result =
                    modelTrainingService.trainModels();

            return ResponseEntity.ok(result);

        } catch (IllegalArgumentException e) {

            return ResponseEntity
                    .badRequest()
                    .body(e.getMessage());

        } catch (Exception e) {

            return ResponseEntity
                    .internalServerError()
                    .body(
                            "ML training failed: "
                                    + e.getMessage()
                    );
        }
    }

    @GetMapping("/evaluation")
    public ResponseEntity<?> getEvaluation() {

        MLTrainingResult result =
                modelTrainingService
                        .getTrainingResult();

        if (result == null) {

            return ResponseEntity
                    .status(404)
                    .body(
                            "Models have not been trained yet. "
                                    + "Call /api/ml/train first."
                    );
        }

        return ResponseEntity.ok(result);
    }

    @GetMapping("/status")
    public ResponseEntity<?> getTrainingStatus() {

        boolean completed =
                modelTrainingService
                        .isTrainingCompleted();

        return ResponseEntity.ok(completed);
    }
}