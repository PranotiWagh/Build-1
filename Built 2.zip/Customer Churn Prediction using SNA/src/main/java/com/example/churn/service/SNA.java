package com.example.churn.service;

import org.jgrapht.Graph;
import org.jgrapht.Graphs;
import org.jgrapht.alg.scoring.BetweennessCentrality;
import org.jgrapht.alg.scoring.ClosenessCentrality;
import org.jgrapht.alg.scoring.PageRank;
import org.jgrapht.graph.DefaultDirectedWeightedGraph;
import org.jgrapht.graph.DefaultWeightedEdge;

import org.springframework.stereotype.Service;

import tech.tablesaw.api.DoubleColumn;
import tech.tablesaw.api.Row;
import tech.tablesaw.api.StringColumn;
import tech.tablesaw.api.Table;

import java.util.HashMap;
import java.util.Map;

@Service
public class SNA {

    /*
     * ============================================================
     * CACHED SNA RESULT
     * ============================================================
     *
     * SNA is expensive, especially betweenness centrality.
     *
     * Therefore, once calculateSNA() finishes, the result is
     * stored here and reused by PredictionService.
     *
     * This prevents recalculating SNA for every prediction.
     * ============================================================
     */

    private volatile Table cachedSnaFeatures;

    private volatile boolean snaCalculated = false;


    /*
     * ============================================================
     * CALCULATE SNA
     * ============================================================
     */
    public synchronized Table calculateSNA(Table cdrTable) {

        /*
         * If SNA has already been calculated, reuse it.
         */
        if (snaCalculated && cachedSnaFeatures != null) {

            System.out.println();
            System.out.println("======================================");
            System.out.println("SNA CACHE");
            System.out.println("======================================");
            System.out.println(
                    "SNA already calculated."
            );
            System.out.println(
                    "Using cached SNA features."
            );

            return cachedSnaFeatures;
        }


        long totalStart =
                System.currentTimeMillis();


        System.out.println();
        System.out.println("======================================");
        System.out.println("SNA CALCULATION");
        System.out.println("======================================");

        System.out.println(
                "Starting SNA calculation..."
        );


        /*
         * ========================================================
         * VALIDATE INPUT
         * ========================================================
         */

        if (cdrTable == null ||
                cdrTable.rowCount() == 0) {

            Table empty =
                    createEmptyResult();

            cachedSnaFeatures = empty;
            snaCalculated = true;

            return empty;
        }


        if (!cdrTable.columnNames()
                .contains("Caller id")) {

            throw new IllegalArgumentException(
                    "CDR table does not contain 'Caller id'. "
                            + "Available columns: "
                            + cdrTable.columnNames()
            );
        }


        if (!cdrTable.columnNames()
                .contains("Receiver id")) {

            throw new IllegalArgumentException(
                    "CDR table does not contain 'Receiver id'. "
                            + "Available columns: "
                            + cdrTable.columnNames()
            );
        }


        System.out.println(
                "CDR rows : "
                        + cdrTable.rowCount()
        );


        /*
         * ========================================================
         * CREATE GRAPH
         * ========================================================
         */

        long graphStart =
                System.currentTimeMillis();


        Graph<String, DefaultWeightedEdge> graph =
                new DefaultDirectedWeightedGraph<>(
                        DefaultWeightedEdge.class
                );


        /*
         * ========================================================
         * BUILD GRAPH
         * ========================================================
         */

        System.out.println();
        System.out.println(
                "Building directed weighted graph..."
        );


        for (int i = 0;
             i < cdrTable.rowCount();
             i++) {

            Row row =
                    cdrTable.row(i);


            String caller =
                    cleanId(
                            getValueAsString(
                                    row,
                                    "Caller id"
                            )
                    );


            String receiver =
                    cleanId(
                            getValueAsString(
                                    row,
                                    "Receiver id"
                            )
                    );


            /*
             * Ignore empty IDs.
             */
            if (caller.isEmpty() ||
                    receiver.isEmpty()) {

                continue;
            }


            /*
             * Ignore self calls.
             */
            if (caller.equalsIgnoreCase(receiver)) {

                continue;
            }


            /*
             * Add vertices.
             */
            graph.addVertex(caller);
            graph.addVertex(receiver);


            /*
             * Check existing edge.
             */
            DefaultWeightedEdge edge =
                    graph.getEdge(
                            caller,
                            receiver
                    );


            /*
             * New edge.
             */
            if (edge == null) {

                edge =
                        graph.addEdge(
                                caller,
                                receiver
                        );

                if (edge != null) {

                    graph.setEdgeWeight(
                            edge,
                            1.0
                    );
                }

            }

            /*
             * Existing edge.
             *
             * Increase call frequency.
             */
            else {

                graph.setEdgeWeight(
                        edge,
                        graph.getEdgeWeight(edge)
                                + 1.0
                );
            }
        }


        long graphEnd =
                System.currentTimeMillis();


        System.out.println(
                "Graph construction completed."
        );

        System.out.println(
                "Graph vertices : "
                        + graph.vertexSet().size()
        );

        System.out.println(
                "Graph edges    : "
                        + graph.edgeSet().size()
        );

        System.out.println(
                "Graph time     : "
                        + elapsed(graphStart, graphEnd)
        );


        /*
         * ========================================================
         * NO GRAPH NODES
         * ========================================================
         */

        if (graph.vertexSet().isEmpty()) {

            Table empty =
                    createEmptyResult();

            cachedSnaFeatures = empty;
            snaCalculated = true;

            return empty;
        }


        /*
         * ========================================================
         * BETWEENNESS CENTRALITY
         * ========================================================
         */

        System.out.println();
        System.out.println(
                "--------------------------------------"
        );

        System.out.println(
                "Calculating betweenness centrality..."
        );

        System.out.println(
                "This may take several minutes."
        );

        System.out.println(
                "Please wait..."
        );


        long betweennessStart =
                System.currentTimeMillis();


        BetweennessCentrality<
                String,
                DefaultWeightedEdge
                > betweennessCentrality =
                new BetweennessCentrality<>(
                        graph
                );


        Map<String, Double> betweenness =
                betweennessCentrality.getScores();


        long betweennessEnd =
                System.currentTimeMillis();


        System.out.println(
                "Betweenness centrality completed."
        );

        System.out.println(
                "Time : "
                        + elapsed(
                        betweennessStart,
                        betweennessEnd
                )
        );


        /*
         * ========================================================
         * CLOSENESS CENTRALITY
         * ========================================================
         */

        System.out.println();
        System.out.println(
                "--------------------------------------"
        );

        System.out.println(
                "Calculating closeness centrality..."
        );

        System.out.println(
                "Please wait..."
        );


        long closenessStart =
                System.currentTimeMillis();


        ClosenessCentrality<
                String,
                DefaultWeightedEdge
                > closenessCentrality =
                new ClosenessCentrality<>(
                        graph
                );


        Map<String, Double> closeness =
                closenessCentrality.getScores();


        long closenessEnd =
                System.currentTimeMillis();


        System.out.println(
                "Closeness centrality completed."
        );

        System.out.println(
                "Time : "
                        + elapsed(
                        closenessStart,
                        closenessEnd
                )
        );


        /*
         * ========================================================
         * PAGERANK / INFLUENCE
         * ========================================================
         */

        System.out.println();
        System.out.println(
                "--------------------------------------"
        );

        System.out.println(
                "Calculating PageRank / influence..."
        );


        long pageRankStart =
                System.currentTimeMillis();


        PageRank<
                String,
                DefaultWeightedEdge
                > pageRank =
                new PageRank<>(
                        graph
                );


        Map<String, Double> influence =
                pageRank.getScores();


        long pageRankEnd =
                System.currentTimeMillis();


        System.out.println(
                "PageRank / influence completed."
        );

        System.out.println(
                "Time : "
                        + elapsed(
                        pageRankStart,
                        pageRankEnd
                )
        );


        /*
         * ========================================================
         * CONFORMITY
         * ========================================================
         */

        System.out.println();
        System.out.println(
                "--------------------------------------"
        );

        System.out.println(
                "Calculating conformity..."
        );


        long conformityStart =
                System.currentTimeMillis();


        Map<String, Double> conformity =
                calculateConformity(graph);


        long conformityEnd =
                System.currentTimeMillis();


        System.out.println(
                "Conformity completed."
        );

        System.out.println(
                "Time : "
                        + elapsed(
                        conformityStart,
                        conformityEnd
                )
        );


        /*
         * ========================================================
         * CREATE TABLE COLUMNS
         * ========================================================
         */

        StringColumn customerId =
                StringColumn.create(
                        "customer_id"
                );


        DoubleColumn inDegree =
                DoubleColumn.create(
                        "in_degree"
                );


        DoubleColumn outDegree =
                DoubleColumn.create(
                        "out_degree"
                );


        DoubleColumn totalDegree =
                DoubleColumn.create(
                        "total_degree"
                );


        DoubleColumn betweennessColumn =
                DoubleColumn.create(
                        "betweenness"
                );


        DoubleColumn closenessColumn =
                DoubleColumn.create(
                        "closeness"
                );


        DoubleColumn influenceColumn =
                DoubleColumn.create(
                        "influence"
                );


        DoubleColumn conformityColumn =
                DoubleColumn.create(
                        "conformity"
                );


        /*
         * ========================================================
         * STORE FEATURES
         * ========================================================
         */

        for (String vertex :
                graph.vertexSet()) {

            customerId.append(vertex);


            double in =
                    graph.inDegreeOf(vertex);


            double out =
                    graph.outDegreeOf(vertex);


            inDegree.append(in);


            outDegree.append(out);


            totalDegree.append(
                    in + out
            );


            betweennessColumn.append(
                    safeMapValue(
                            betweenness,
                            vertex
                    )
            );


            closenessColumn.append(
                    safeMapValue(
                            closeness,
                            vertex
                    )
            );


            influenceColumn.append(
                    safeMapValue(
                            influence,
                            vertex
                    )
            );


            conformityColumn.append(
                    safeMapValue(
                            conformity,
                            vertex
                    )
            );
        }


        /*
         * ========================================================
         * CREATE FINAL SNA TABLE
         * ========================================================
         */

        Table result =
                Table.create(
                        "SNA Features",
                        customerId,
                        inDegree,
                        outDegree,
                        totalDegree,
                        betweennessColumn,
                        closenessColumn,
                        influenceColumn,
                        conformityColumn
                );


        /*
         * ========================================================
         * CACHE RESULT
         * ========================================================
         */

        cachedSnaFeatures =
                result;

        snaCalculated =
                true;


        long totalEnd =
                System.currentTimeMillis();


        System.out.println();
        System.out.println(
                "======================================"
        );

        System.out.println(
                "SNA CALCULATION COMPLETED"
        );

        System.out.println(
                "======================================"
        );

        System.out.println(
                "SNA customers : "
                        + result.rowCount()
        );

        System.out.println(
                "Total time    : "
                        + elapsed(
                        totalStart,
                        totalEnd
                )
        );

        System.out.println(
                "SNA result has been cached."
        );

        System.out.println(
                "Future predictions will reuse it."
        );

        System.out.println(
                "======================================"
        );


        return result;
    }


    /*
     * ============================================================
     * CHECK WHETHER SNA IS ALREADY CALCULATED
     * ============================================================
     */

    public boolean isSnaCalculated() {

        return snaCalculated &&
                cachedSnaFeatures != null;
    }


    /*
     * ============================================================
     * GET CACHED SNA FEATURES
     * ============================================================
     *
     * PredictionService uses this method so it does NOT reload
     * CDR data and recalculate centrality for every prediction.
     * ============================================================
     */

    public Table getCachedSnaFeatures() {

        return cachedSnaFeatures;
    }


    /*
     * ============================================================
     * CLEAR CACHE
     * ============================================================
     *
     * Useful if you replace the CDR file and want to calculate
     * SNA again.
     * ============================================================
     */

    public synchronized void clearCache() {

        cachedSnaFeatures = null;

        snaCalculated = false;

        System.out.println(
                "SNA cache cleared."
        );
    }


    /*
     * ============================================================
     * CONFORMITY
     * ============================================================
     */

    private Map<String, Double>
    calculateConformity(
            Graph<String, DefaultWeightedEdge> graph) {

        Map<String, Double> result =
                new HashMap<>();


        for (String customer :
                graph.vertexSet()) {

            double customerDegree =
                    graph.degreeOf(customer);


            double neighborDegreeSum =
                    0.0;


            int neighborCount =
                    0;


            /*
             * Successors.
             */
            for (String neighbor :
                    Graphs.successorListOf(
                            graph,
                            customer
                    )) {

                neighborDegreeSum +=
                        graph.degreeOf(neighbor);

                neighborCount++;
            }


            /*
             * Predecessors.
             */
            for (String neighbor :
                    Graphs.predecessorListOf(
                            graph,
                            customer
                    )) {

                if (!neighbor.equals(customer)) {

                    neighborDegreeSum +=
                            graph.degreeOf(neighbor);

                    neighborCount++;
                }
            }


            /*
             * No neighbors.
             */
            if (neighborCount == 0) {

                result.put(
                        customer,
                        0.0
                );

                continue;
            }


            double averageNeighborDegree =
                    neighborDegreeSum /
                            neighborCount;


            double conformityValue =
                    1.0 /
                            (
                                    1.0 +
                                            Math.abs(
                                                    customerDegree
                                                            -
                                                            averageNeighborDegree
                                            )
                            );


            result.put(
                    customer,
                    conformityValue
            );
        }


        return result;
    }


    /*
     * ============================================================
     * GET SNA FOR ONE CUSTOMER
     * ============================================================
     */

    public CustomerSNAResult getCustomerSNA(
            Table networkFeatures,
            String customerId) {

        if (networkFeatures == null ||
                customerId == null) {

            return createEmptyCustomerResult();
        }


        String requestedId =
                cleanId(customerId);


        if (requestedId.isEmpty()) {

            return createEmptyCustomerResult();
        }


        /*
         * Search exact customer ID.
         */
        for (int i = 0;
             i < networkFeatures.rowCount();
             i++) {

            Row row =
                    networkFeatures.row(i);


            String id =
                    cleanId(
                            getValueAsString(
                                    row,
                                    "customer_id"
                            )
                    );


            if (requestedId.equalsIgnoreCase(id)) {

                return new CustomerSNAResult(

                        getDoubleValue(
                                row,
                                "in_degree"
                        ),

                        getDoubleValue(
                                row,
                                "out_degree"
                        ),

                        getDoubleValue(
                                row,
                                "total_degree"
                        ),

                        getDoubleValue(
                                row,
                                "betweenness"
                        ),

                        getDoubleValue(
                                row,
                                "closeness"
                        ),

                        getDoubleValue(
                                row,
                                "influence"
                        ),

                        getDoubleValue(
                                row,
                                "conformity"
                        )
                );
            }
        }


        /*
         * Customer not present in CDR.
         */
        return createEmptyCustomerResult();
    }


    /*
     * ============================================================
     * EMPTY CUSTOMER RESULT
     * ============================================================
     */

    private CustomerSNAResult
    createEmptyCustomerResult() {

        return new CustomerSNAResult(
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0
        );
    }


    /*
     * ============================================================
     * EMPTY TABLE
     * ============================================================
     */

    private Table createEmptyResult() {

        return Table.create(
                "SNA Features",

                StringColumn.create(
                        "customer_id"
                ),

                DoubleColumn.create(
                        "in_degree"
                ),

                DoubleColumn.create(
                        "out_degree"
                ),

                DoubleColumn.create(
                        "total_degree"
                ),

                DoubleColumn.create(
                        "betweenness"
                ),

                DoubleColumn.create(
                        "closeness"
                ),

                DoubleColumn.create(
                        "influence"
                ),

                DoubleColumn.create(
                        "conformity"
                )
        );
    }


    /*
     * ============================================================
     * GET TABLESAW VALUE AS STRING
     * ============================================================
     */

    private String getValueAsString(
            Row row,
            String columnName) {

        try {

            Object value =
                    row.getObject(
                            columnName
                    );


            if (value == null) {

                return "";
            }


            return String.valueOf(value)
                    .trim();

        } catch (Exception e) {

            return "";
        }
    }


    /*
     * ============================================================
     * GET TABLESAW VALUE AS DOUBLE
     * ============================================================
     */

    private double getDoubleValue(
            Row row,
            String columnName) {

        try {

            Object value =
                    row.getObject(
                            columnName
                    );


            if (value == null) {

                return 0.0;
            }


            if (value instanceof Number) {

                double number =
                        ((Number) value)
                                .doubleValue();


                if (Double.isNaN(number) ||
                        Double.isInfinite(number)) {

                    return 0.0;
                }


                return number;
            }


            String text =
                    String.valueOf(value)
                            .trim();


            if (text.isEmpty()) {

                return 0.0;
            }


            double number =
                    Double.parseDouble(text);


            if (Double.isNaN(number) ||
                    Double.isInfinite(number)) {

                return 0.0;
            }


            return number;

        } catch (Exception e) {

            return 0.0;
        }
    }


    /*
     * ============================================================
     * CLEAN CUSTOMER / CDR ID
     * ============================================================
     */

    private String cleanId(String value) {

        if (value == null) {

            return "";
        }


        String cleaned =
                value
                        .trim()
                        .replace(
                                "\uFEFF",
                                ""
                        );


        /*
         * Remove surrounding quotes.
         */
        if (cleaned.length() >= 2 &&
                cleaned.startsWith("\"") &&
                cleaned.endsWith("\"")) {

            cleaned =
                    cleaned.substring(
                            1,
                            cleaned.length() - 1
                    ).trim();
        }


        /*
         * Handle numeric values such as 12345.0.
         *
         * IMPORTANT:
         * This does NOT modify IDs such as
         * 9237-HQITU.
         */
        if (cleaned.matches(
                "\\d+\\.0+"
        )) {

            cleaned =
                    cleaned.substring(
                            0,
                            cleaned.indexOf('.')
                    );
        }


        return cleaned;
    }


    /*
     * ============================================================
     * SAFE MAP VALUE
     * ============================================================
     */

    private double safeMapValue(
            Map<String, Double> map,
            String key) {

        if (map == null ||
                key == null) {

            return 0.0;
        }


        Double value =
                map.get(key);


        if (value == null) {

            return 0.0;
        }


        if (Double.isNaN(value) ||
                Double.isInfinite(value)) {

            return 0.0;
        }


        return value;
    }


    /*
     * ============================================================
     * TIME FORMAT
     * ============================================================
     */

    private String elapsed(
            long start,
            long end) {

        long milliseconds =
                end - start;


        if (milliseconds < 1000) {

            return milliseconds
                    + " ms";
        }


        double seconds =
                milliseconds / 1000.0;


        if (seconds < 60) {

            return String.format(
                    "%.2f seconds",
                    seconds
            );
        }


        double minutes =
                seconds / 60.0;


        return String.format(
                "%.2f minutes",
                minutes
        );
    }


    /*
     * ============================================================
     * CUSTOMER SNA RESULT
     * ============================================================
     */

    public static class CustomerSNAResult {

        private final double inDegree;

        private final double outDegree;

        private final double totalDegree;

        private final double betweenness;

        private final double closeness;

        private final double influence;

        private final double conformity;


        public CustomerSNAResult(
                double inDegree,
                double outDegree,
                double totalDegree,
                double betweenness,
                double closeness,
                double influence,
                double conformity) {

            this.inDegree =
                    inDegree;

            this.outDegree =
                    outDegree;

            this.totalDegree =
                    totalDegree;

            this.betweenness =
                    betweenness;

            this.closeness =
                    closeness;

            this.influence =
                    influence;

            this.conformity =
                    conformity;
        }


        public double getInDegree() {

            return inDegree;
        }


        public double getOutDegree() {

            return outDegree;
        }


        public double getTotalDegree() {

            return totalDegree;
        }


        public double getBetweenness() {

            return betweenness;
        }


        public double getCloseness() {

            return closeness;
        }


        public double getInfluence() {

            return influence;
        }


        public double getConformity() {

            return conformity;
        }
    }
}