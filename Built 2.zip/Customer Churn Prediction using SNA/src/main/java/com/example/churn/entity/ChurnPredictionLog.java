package com.example.churn.entity;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "churn_predictions")
public class ChurnPredictionLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String customerId;

    @Column(nullable = false)
    private String prediction;

    private double churnProbability;

    private double inDegree;

    private double outDegree;

    private double pageRankScore;

    private double closenessCentrality;

    private LocalDateTime createdAt;

    public ChurnPredictionLog() {
    }

    public ChurnPredictionLog(
            String customerId,
            String prediction,
            double churnProbability,
            double inDegree,
            double outDegree,
            double pageRankScore,
            double closenessCentrality) {

        this.customerId = customerId;
        this.prediction = prediction;
        this.churnProbability = churnProbability;
        this.inDegree = inDegree;
        this.outDegree = outDegree;
        this.pageRankScore = pageRankScore;
        this.closenessCentrality = closenessCentrality;
        this.createdAt = LocalDateTime.now();
    }

    @PrePersist
    protected void onCreate() {

        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getPrediction() {
        return prediction;
    }

    public void setPrediction(String prediction) {
        this.prediction = prediction;
    }

    public double getChurnProbability() {
        return churnProbability;
    }

    public void setChurnProbability(double churnProbability) {
        this.churnProbability = churnProbability;
    }

    public double getInDegree() {
        return inDegree;
    }

    public void setInDegree(double inDegree) {
        this.inDegree = inDegree;
    }

    public double getOutDegree() {
        return outDegree;
    }

    public void setOutDegree(double outDegree) {
        this.outDegree = outDegree;
    }

    public double getPageRankScore() {
        return pageRankScore;
    }

    public void setPageRankScore(double pageRankScore) {
        this.pageRankScore = pageRankScore;
    }

    public double getClosenessCentrality() {
        return closenessCentrality;
    }

    public void setClosenessCentrality(double closenessCentrality) {
        this.closenessCentrality = closenessCentrality;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}