package com.example.churn.service;

import org.springframework.stereotype.Service;

import tech.tablesaw.api.DoubleColumn;
import tech.tablesaw.api.Row;
import tech.tablesaw.api.StringColumn;
import tech.tablesaw.api.Table;

import java.util.HashMap;
import java.util.Map;

@Service
public class FeatureMerging {

    /*
     * ============================================================
     * MERGE CUSTOMER DATA + SNA FEATURES
     * ============================================================
     *
     * Customer table:
     *     customerID
     *
     * SNA table:
     *     customer_id
     *
     * SNA features:
     *     in_degree
     *     out_degree
     *     total_degree
     *     betweenness
     *     closeness
     *     influence
     *     conformity
     *
     * IMPORTANT:
     * Customer IDs are matched EXACTLY.
     *
     * Example:
     *     9237-HQITU
     *     9237-HQITU
     *
     * No numeric conversion is performed.
     * No part of the ID is removed.
     */
    public Table merge(
            Table customerData,
            Table networkFeatures) {

        System.out.println();
        System.out.println("======================================");
        System.out.println("FEATURE MERGING");
        System.out.println("======================================");

        if (customerData == null) {
            throw new IllegalArgumentException(
                    "Customer data cannot be null."
            );
        }

        if (networkFeatures == null) {
            throw new IllegalArgumentException(
                    "Network/SNA features cannot be null."
            );
        }

        System.out.println(
                "Customer rows : "
                        + customerData.rowCount()
        );

        System.out.println(
                "SNA rows      : "
                        + networkFeatures.rowCount()
        );

        /*
         * ========================================================
         * CHECK CUSTOMER ID COLUMN
         * ========================================================
         */

        if (!customerData.columnNames()
                .contains("customerID")) {

            throw new IllegalArgumentException(
                    "Customer table does not contain 'customerID'. "
                            + "Available columns: "
                            + customerData.columnNames()
            );
        }

        /*
         * ========================================================
         * CHECK SNA ID COLUMN
         * ========================================================
         */

        if (!networkFeatures.columnNames()
                .contains("customer_id")) {

            throw new IllegalArgumentException(
                    "SNA table does not contain 'customer_id'. "
                            + "Available columns: "
                            + networkFeatures.columnNames()
            );
        }

        /*
         * ========================================================
         * BUILD SNA MAP
         * ========================================================
         *
         * Key:
         *     customer_id
         *
         * Value:
         *     seven SNA values
         */

        Map<String, double[]> snaMap =
                new HashMap<>();

        for (Row row : networkFeatures) {

            String customerId =
                    safeString(
                            row,
                            "customer_id"
                    );

            if (customerId == null ||
                    customerId.isEmpty()) {

                continue;
            }

            double inDegree =
                    safeDouble(
                            row,
                            "in_degree"
                    );

            double outDegree =
                    safeDouble(
                            row,
                            "out_degree"
                    );

            double totalDegree =
                    safeDouble(
                            row,
                            "total_degree"
                    );

            double betweenness =
                    safeDouble(
                            row,
                            "betweenness"
                    );

            double closeness =
                    safeDouble(
                            row,
                            "closeness"
                    );

            double influence =
                    safeDouble(
                            row,
                            "influence"
                    );

            double conformity =
                    safeDouble(
                            row,
                            "conformity"
                    );

            snaMap.put(
                    customerId,
                    new double[] {
                            inDegree,
                            outDegree,
                            totalDegree,
                            betweenness,
                            closeness,
                            influence,
                            conformity
                    }
            );
        }

        /*
         * ========================================================
         * CREATE SNA COLUMNS
         * ========================================================
         */

        DoubleColumn inDegreeColumn =
                DoubleColumn.create("In Degree");

        DoubleColumn outDegreeColumn =
                DoubleColumn.create("Out Degree");

        DoubleColumn totalDegreeColumn =
                DoubleColumn.create("Total Degree");

        DoubleColumn betweennessColumn =
                DoubleColumn.create("Betweenness");

        DoubleColumn closenessColumn =
                DoubleColumn.create("Closeness");

        DoubleColumn influenceColumn =
                DoubleColumn.create("Influence");

        DoubleColumn conformityColumn =
                DoubleColumn.create("Conformity");

        /*
         * ========================================================
         * MERGE EACH CUSTOMER WITH SNA
         * ========================================================
         */

        int matched = 0;
        int unmatched = 0;

        for (Row row : customerData) {

            String customerId =
                    safeString(
                            row,
                            "customerID"
                    );

            /*
             * Try exact match.
             */
            double[] snaValues =
                    customerId == null
                            ? null
                            : snaMap.get(customerId);

            /*
             * ====================================================
             * MATCH FOUND
             * ====================================================
             */

            if (snaValues != null) {

                inDegreeColumn.append(
                        snaValues[0]
                );

                outDegreeColumn.append(
                        snaValues[1]
                );

                totalDegreeColumn.append(
                        snaValues[2]
                );

                betweennessColumn.append(
                        snaValues[3]
                );

                closenessColumn.append(
                        snaValues[4]
                );

                influenceColumn.append(
                        snaValues[5]
                );

                conformityColumn.append(
                        snaValues[6]
                );

                matched++;

            }

            /*
             * ====================================================
             * NO MATCH
             * ====================================================
             *
             * Customer exists in telecom dataset but does not
             * exist in the CDR/SNA graph.
             *
             * In this case all SNA features are 0.
             */

            else {

                inDegreeColumn.append(0.0);
                outDegreeColumn.append(0.0);
                totalDegreeColumn.append(0.0);
                betweennessColumn.append(0.0);
                closenessColumn.append(0.0);
                influenceColumn.append(0.0);
                conformityColumn.append(0.0);

                unmatched++;
            }
        }

        /*
         * ========================================================
         * CREATE FINAL DATASET
         * ========================================================
         */

        Table finalDataset =
                customerData.copy();

        /*
         * Remove old SNA columns if this method is called more
         * than once.
         */

        removeIfExists(
                finalDataset,
                "In Degree"
        );

        removeIfExists(
                finalDataset,
                "Out Degree"
        );

        removeIfExists(
                finalDataset,
                "Total Degree"
        );

        removeIfExists(
                finalDataset,
                "Betweenness"
        );

        removeIfExists(
                finalDataset,
                "Closeness"
        );

        removeIfExists(
                finalDataset,
                "Influence"
        );

        removeIfExists(
                finalDataset,
                "Conformity"
        );

        /*
         * Add the seven SNA features.
         */

        finalDataset.addColumns(
                inDegreeColumn,
                outDegreeColumn,
                totalDegreeColumn,
                betweennessColumn,
                closenessColumn,
                influenceColumn,
                conformityColumn
        );

        /*
         * ========================================================
         * PRINT RESULT
         * ========================================================
         */

        System.out.println(
                "Matched SNA customers   : "
                        + matched
        );

        System.out.println(
                "Unmatched customers     : "
                        + unmatched
        );

        System.out.println(
                "Final rows              : "
                        + finalDataset.rowCount()
        );

        System.out.println(
                "Final columns           : "
                        + finalDataset.columnNames()
        );

        System.out.println(
                "======================================"
        );

        /*
         * ========================================================
         * PRINT FIRST FEW MERGED RECORDS
         * ========================================================
         */

        int displayRows =
                Math.min(
                        5,
                        finalDataset.rowCount()
                );

        System.out.println();
        System.out.println(
                "First "
                        + displayRows
                        + " merged customers:"
        );

        for (int i = 0;
             i < displayRows;
             i++) {

            Row row =
                    finalDataset.row(i);

            System.out.println(
                    "Customer ID: "
                            + safeString(
                                    row,
                                    "customerID"
                            )
            );

            System.out.println(
                    "In Degree: "
                            + safeDouble(
                                    row,
                                    "In Degree"
                            )
            );

            System.out.println(
                    "Out Degree: "
                            + safeDouble(
                                    row,
                                    "Out Degree"
                            )
            );

            System.out.println(
                    "Total Degree: "
                            + safeDouble(
                                    row,
                                    "Total Degree"
                            )
            );

            System.out.println(
                    "Betweenness: "
                            + safeDouble(
                                    row,
                                    "Betweenness"
                            )
            );

            System.out.println(
                    "Closeness: "
                            + safeDouble(
                                    row,
                                    "Closeness"
                            )
            );

            System.out.println(
                    "Influence: "
                            + safeDouble(
                                    row,
                                    "Influence"
                            )
            );

            System.out.println(
                    "Conformity: "
                            + safeDouble(
                                    row,
                                    "Conformity"
                            )
            );

            System.out.println(
                    "--------------------------------------"
            );
        }

        return finalDataset;
    }

    /*
     * ============================================================
     * SAFE STRING
     * ============================================================
     */

    private String safeString(
            Row row,
            String columnName) {

        try {

            Object value =
                    row.getObject(columnName);

            if (value == null) {
                return null;
            }

            String result =
                    value.toString()
                            .trim();

            if (result.isEmpty()) {
                return null;
            }

            /*
             * Remove UTF-8 BOM if present.
             */

            result =
                    result.replace(
                            "\uFEFF",
                            ""
                    ).trim();

            /*
             * Remove surrounding quotes if present.
             */

            if (result.length() >= 2 &&
                    result.startsWith("\"") &&
                    result.endsWith("\"")) {

                result =
                        result.substring(
                                1,
                                result.length() - 1
                        ).trim();
            }

            return result;

        } catch (Exception e) {

            return null;
        }
    }

    /*
     * ============================================================
     * SAFE DOUBLE
     * ============================================================
     */

    private double safeDouble(
            Row row,
            String columnName) {

        try {

            Object value =
                    row.getObject(columnName);

            if (value == null) {
                return 0.0;
            }

            if (value instanceof Number) {

                double number =
                        ((Number) value)
                                .doubleValue();

                if (Double.isNaN(number) ||
                        Double.isInfinite(number)) {

                    return 0.0;
                }

                return number;
            }

            String text =
                    value.toString()
                            .trim();

            if (text.isEmpty()) {
                return 0.0;
            }

            double number =
                    Double.parseDouble(text);

            if (Double.isNaN(number) ||
                    Double.isInfinite(number)) {

                return 0.0;
            }

            return number;

        } catch (Exception e) {

            return 0.0;
        }
    }

    /*
     * ============================================================
     * REMOVE COLUMN IF IT EXISTS
     * ============================================================
     */

    private void removeIfExists(
            Table table,
            String columnName) {

        if (table.columnNames()
                .contains(columnName)) {

            table.removeColumns(
                    columnName
            );
        }
    }
}