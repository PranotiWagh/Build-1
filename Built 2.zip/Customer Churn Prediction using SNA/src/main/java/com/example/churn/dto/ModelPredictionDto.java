package com.example.churn.dto;

public class ModelPredictionDto {

    private String algorithm;

    private String prediction;

    private Double probability;

    public ModelPredictionDto() {
    }

    public ModelPredictionDto(
            String algorithm,
            String prediction,
            Double probability) {

        this.algorithm = algorithm;
        this.prediction = prediction;
        this.probability = probability;
    }

    public String getAlgorithm() {
        return algorithm;
    }

    public void setAlgorithm(String algorithm) {
        this.algorithm = algorithm;
    }

    public String getPrediction() {
        return prediction;
    }

    public void setPrediction(String prediction) {
        this.prediction = prediction;
    }

    public Double getProbability() {
        return probability;
    }

    public void setProbability(Double probability) {
        this.probability = probability;
    }
}