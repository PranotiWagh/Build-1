let selectedCustomerId = null;


document.addEventListener(
    "DOMContentLoaded",
    function () {

        requireLogin();

        const input =
            document.getElementById(
                "customerId"
            );

        if (input) {

            input.addEventListener(
                "keydown",
                function (event) {

                    if (
                        event.key === "Enter"
                    ) {

                        event.preventDefault();

                        searchCustomer();
                    }
                }
            );
        }
    }
);


async function searchCustomer() {

    const input =
        document.getElementById(
            "customerId"
        );

    const customerId =
        input.value.trim();

    if (!customerId) {

        showMessage(
            "customerMessage",
            "Please enter a Customer ID.",
            "error"
        );

        input.focus();

        return;
    }

    selectedCustomerId =
        customerId;

    const button =
        document.getElementById(
            "searchButton"
        );

    setButtonLoading(
        button,
        true,
        "Searching..."
    );

    try {

        const data =
            await apiGet(
                "/api/customer/" +
                encodeURIComponent(
                    customerId
                )
            );

        renderCustomer(data);

        showMessage(
            "customerMessage",
            ""
        );

    } catch (error) {

        document
            .getElementById(
                "customerDetails"
            )
            .classList.add("hidden");

        showMessage(
            "customerMessage",
            error.message ||
                "Customer not found.",
            "error"
        );

    } finally {

        setButtonLoading(
            button,
            false
        );
    }
}


function renderCustomer(data) {

    document
        .getElementById(
            "customerDetails"
        )
        .classList.remove("hidden");

    setText(
        "resultCustomerId",
        data.customerId
    );

    setText(
        "gender",
        data.gender
    );

    setText(
        "seniorCitizen",
        data.seniorCitizen
    );

    setText(
        "partner",
        data.partner
    );

    setText(
        "dependents",
        data.dependents
    );

    setText(
        "tenure",
        data.tenure
    );

    setText(
        "phoneService",
        data.phoneService
    );

    setText(
        "internetService",
        data.internetService
    );

    setText(
        "contract",
        data.contract
    );

    setText(
        "paymentMethod",
        data.paymentMethod
    );

    setText(
        "monthlyCharges",
        formatCurrency(
            data.monthlyCharges
        )
    );

    setText(
        "totalCharges",
        formatCurrency(
            data.totalCharges
        )
    );
}


function predictCustomer() {

    if (!selectedCustomerId) {

        showMessage(
            "customerMessage",
            "Search for a customer first.",
            "error"
        );

        return;
    }

    window.location.href =
        "/prediction.html?customerId=" +
        encodeURIComponent(
            selectedCustomerId
        );
}