const API = {
    AUTH: "/api/auth",
    CUSTOMER: "/api/customer",
    PREDICTION: "/api/prediction",
    ML: "/api/ml",
    SNA: "/api/sna",
    DASHBOARD: "/api/dashboard"
};


/* =========================
   GENERIC API
   ========================= */

async function apiRequest(url, options = {}) {

    const response = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            ...(options.headers || {})
        },
        ...options
    });

    const contentType =
        response.headers.get("content-type") || "";

    let data;

    if (contentType.includes("application/json")) {
        data = await response.json();
    } else {
        data = await response.text();
    }

    if (!response.ok) {

        let message = "Request failed.";

        if (typeof data === "string" && data.trim()) {
            message = data;
        } else if (data && data.message) {
            message = data.message;
        } else if (data && data.error) {
            message = data.error;
        }

        throw new Error(message);
    }

    return data;
}


async function apiGet(url) {
    return apiRequest(url, {
        method: "GET"
    });
}


async function apiPost(url, body = null) {

    const options = {
        method: "POST"
    };

    if (body !== null) {
        options.body = JSON.stringify(body);
    }

    return apiRequest(url, options);
}


/* =========================
   LOGIN
   ========================= */

function saveLoginData(data) {

    if (!data) return;

    if (data.userId !== undefined) {
        localStorage.setItem("userId", data.userId);
    }

    if (data.name) {
        localStorage.setItem("userName", data.name);
    }

    if (data.email) {
        localStorage.setItem("userEmail", data.email);
    }

    localStorage.setItem("isLoggedIn", "true");
    localStorage.setItem("loggedIn", "true");
}


function isLoggedIn() {
    return (
        localStorage.getItem("isLoggedIn") === "true" ||
        localStorage.getItem("loggedIn") === "true"
    );
}


function getLoggedInUser() {

    return {
        userId: localStorage.getItem("userId"),
        name: localStorage.getItem("userName"),
        email: localStorage.getItem("userEmail")
    };
}


function requireLogin() {

    if (!isLoggedIn()) {
        window.location.href = "/login.html";
        return false;
    }

    return true;
}


function redirectIfLoggedIn() {

    if (isLoggedIn()) {
        window.location.href = "/dashboard.html";
        return true;
    }

    return false;
}


/* =========================
   LOGOUT
   ========================= */

async function logout() {

    try {

        await apiPost(`${API.AUTH}/logout`);

    } catch (error) {

        console.warn("Backend logout request failed:", error);

    } finally {

        localStorage.removeItem("isLoggedIn");
        localStorage.removeItem("loggedIn");
        localStorage.removeItem("userId");
        localStorage.removeItem("userName");
        localStorage.removeItem("userEmail");

        sessionStorage.clear();

        window.location.href = "/login.html";
    }
}


async function logoutUser() {

    if (!confirm("Are you sure you want to logout?")) {
        return;
    }

    await logout();
}


/* =========================
   BUTTON
   ========================= */

function setButtonLoading(button, loading, loadingText = "Processing...") {

    if (!button) return;

    if (loading) {

        button.dataset.originalText = button.innerHTML;
        button.disabled = true;
        button.innerHTML = loadingText;

    } else {

        button.disabled = false;

        if (button.dataset.originalText) {
            button.innerHTML = button.dataset.originalText;
        }
    }
}


/* =========================
   MESSAGE
   ========================= */

function showMessage(elementId, message, type = "info") {

    const element = document.getElementById(elementId);

    if (!element) return;

    element.textContent = message;

    element.classList.remove("hidden", "error", "success", "info");

    if (message) {
        element.classList.add(type);
    } else {
        element.classList.add("hidden");
    }
}


function showError(message, elementId = null) {

    if (elementId) {
        showMessage(elementId, message, "error");
        return;
    }

    console.error("Error:", message);
}


/* =========================
   FORMATTING
   ========================= */

function safeNumber(value, defaultValue = 0) {

    const number = Number(value);

    if (Number.isNaN(number) || !Number.isFinite(number)) {
        return defaultValue;
    }

    return number;
}


function formatNumber(value, decimals = 2) {
    return safeNumber(value).toFixed(decimals);
}


function percentValue(value) {

    let number = safeNumber(value);

    if (number >= 0 && number <= 1) {
        number *= 100;
    }

    return Math.max(0, Math.min(100, number));
}


function formatPercentage(value, decimals = 2) {
    return percentValue(value).toFixed(decimals) + "%";
}


function formatCurrency(value) {

    const number = Number(value);

    if (
        value === null ||
        value === undefined ||
        value === "" ||
        Number.isNaN(number)
    ) {
        return "-";
    }

    /* Indian Rupee format, e.g. ₹1,23,456.78 */
    return "₹" + number.toLocaleString("en-IN", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}


function formatDate(value) {

    if (!value) return "-";

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return value;
    }

    return date.toLocaleString();
}


function escapeHtml(value) {

    if (value === null || value === undefined) {
        return "";
    }

    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}


function setText(id, value) {

    const element = document.getElementById(id);

    if (element) {
        element.textContent = value ?? "-";
    }
}


/* =========================
   PASSWORD
   ========================= */

function togglePassword(inputId, button) {

    const input = document.getElementById(inputId);

    if (!input) return;

    const isPassword = input.type === "password";

    input.type = isPassword ? "text" : "password";
    button.textContent = isPassword ? "🙈" : "👁";
}


/* =========================
   CHURN STATUS
   ========================= */

function getChurnStatus(value) {

    const v = String(value ?? "").trim().toLowerCase();

    if (["1", "yes", "true", "churn", "churned"].includes(v)) {
        return "churn";
    }

    if (
        ["0", "no", "false", "no churn", "no-churn",
         "non-churn", "non churn", "nonchurn"].includes(v)
    ) {
        return "no-churn";
    }

    return "unknown";
}


function predictionBadge(value) {

    const status = getChurnStatus(value);

    if (status === "churn") {
        return `
            <span class="status-badge churn">
                Churn
            </span>
        `;
    }

    if (status === "no-churn") {
        return `
            <span class="status-badge no-churn">
                No Churn
            </span>
        `;
    }

    return `
        <span class="status-badge unknown">
            ${escapeHtml(value ?? "-")}
        </span>
    `;
}


/* =========================
   NAVBAR
   ========================= */

function setActiveNavLink() {

    const currentPage =
        window.location.pathname.split("/").pop() || "index.html";

    document.querySelectorAll(".navbar nav a").forEach(link => {

        const target =
            (link.getAttribute("href") || "").split("/").pop();

        link.classList.toggle("active", target === currentPage);
    });
}


function renderNavUser() {

    const chip = document.getElementById("navUser");

    if (!chip || !isLoggedIn()) {
        return;
    }

    const user = getLoggedInUser();

    chip.textContent = user.email || user.name || "Account";
}


document.addEventListener("DOMContentLoaded", function () {

    setActiveNavLink();
    renderNavUser();
});