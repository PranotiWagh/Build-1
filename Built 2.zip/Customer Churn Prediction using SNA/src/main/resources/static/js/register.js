document.addEventListener(
    "DOMContentLoaded",
    function () {

        redirectIfLoggedIn();

        const form =
            document.getElementById(
                "registerForm"
            );

        if (!form) return;

        form.addEventListener(
            "submit",
            async function (event) {

                event.preventDefault();

                const name =
                    document.getElementById(
                        "name"
                    ).value.trim();

                const email =
                    document.getElementById(
                        "email"
                    ).value.trim();

                const password =
                    document.getElementById(
                        "password"
                    ).value;

                const confirmPassword =
                    document.getElementById(
                        "confirmPassword"
                    ).value;

                const button =
                    form.querySelector(
                        "button[type='submit']"
                    );

                if (
                    !name ||
                    !email ||
                    !password ||
                    !confirmPassword
                ) {

                    showMessage(
                        "registerMessage",
                        "Please fill all fields.",
                        "error"
                    );

                    return;
                }

                if (password !== confirmPassword) {

                    showMessage(
                        "registerMessage",
                        "Passwords do not match.",
                        "error"
                    );

                    return;
                }

                if (password.length < 6) {

                    showMessage(
                        "registerMessage",
                        "Password must contain at least 6 characters.",
                        "error"
                    );

                    return;
                }

                setButtonLoading(
                    button,
                    true,
                    "Registering..."
                );

                try {

                    const data =
                        await apiPost(
                            "/api/auth/register",
                            {
                                name: name,
                                email: email,
                                password: password
                            }
                        );

                    if (
                        data &&
                        data.success === false
                    ) {

                        throw new Error(
                            data.message ||
                            "Registration failed."
                        );
                    }

                    showMessage(
                        "registerMessage",
                        "Registration successful. Redirecting to login...",
                        "success"
                    );

                    setTimeout(
                        function () {

                            window.location.href =
                                "/login.html";

                        },
                        800
                    );

                } catch (error) {

                    showMessage(
                        "registerMessage",
                        error.message ||
                            "Registration failed.",
                        "error"
                    );

                } finally {

                    setButtonLoading(
                        button,
                        false
                    );
                }
            }
        );
    }
);