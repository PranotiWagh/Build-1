document.addEventListener(
    "DOMContentLoaded",
    function () {

        redirectIfLoggedIn();

        const form =
            document.getElementById(
                "loginForm"
            );

        if (!form) return;

        form.addEventListener(
            "submit",
            async function (event) {

                event.preventDefault();

                const email =
                    document.getElementById(
                        "email"
                    ).value.trim();

                const password =
                    document.getElementById(
                        "password"
                    ).value;

                const button =
                    form.querySelector(
                        "button[type='submit']"
                    );

                if (!email || !password) {

                    showMessage(
                        "loginMessage",
                        "Please enter email and password.",
                        "error"
                    );

                    return;
                }

                setButtonLoading(
                    button,
                    true,
                    "Logging in..."
                );

                try {

                    const data =
                        await apiPost(
                            "/api/auth/login",
                            {
                                email: email,
                                password: password
                            }
                        );

                    if (
                        data &&
                        data.success === false
                    ) {
                        throw new Error(
                            data.message ||
                            "Invalid email or password."
                        );
                    }

                    saveLoginData(data);

                    showMessage(
                        "loginMessage",
                        "Login successful. Redirecting...",
                        "success"
                    );

                    setTimeout(
                        function () {

                            window.location.href =
                                "/dashboard.html";

                        },
                        600
                    );

                } catch (error) {

                    showMessage(
                        "loginMessage",
                        error.message ||
                            "Login failed.",
                        "error"
                    );

                } finally {

                    setButtonLoading(
                        button,
                        false
                    );
                }
            }
        );
    }
);