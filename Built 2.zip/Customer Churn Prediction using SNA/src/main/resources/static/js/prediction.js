document.addEventListener(
    "DOMContentLoaded",
    function () {

        requireLogin();

        const params =
            new URLSearchParams(
                window.location.search
            );

        const customerId =
            params.get("customerId");

        if (customerId) {

            const input =
                document.getElementById(
                    "predictionCustomerId"
                );

            if (input) {
                input.value = customerId;
            }

            runPrediction();
        }
    }
);


/*
 * ==========================================
 * RUN PREDICTION
 * ==========================================
 */

function runPrediction() {

    const input =
        document.getElementById(
            "predictionCustomerId"
        );

    if (!input) {
        return;
    }

    const customerId =
        input.value.trim();

    if (!customerId) {

        showMessage(
            "predictionMessage",
            "Please enter a Customer ID."
        );

        return;
    }

    showMessage(
        "predictionMessage",
        "Running prediction..."
    );

    fetch(
        "/api/prediction/customer/" +
        encodeURIComponent(customerId)
    )

        .then(async response => {

            const data =
                await response
                    .json()
                    .catch(() => null);

            if (!response.ok) {

                let message =
                    "Prediction failed.";

                if (data) {

                    if (typeof data === "string") {
                        message = data;
                    }

                    else if (data.message) {
                        message = data.message;
                    }

                    else if (data.error) {
                        message = data.error;
                    }
                }

                throw new Error(message);
            }

            return data;
        })

        .then(data => {

            const result =
                document.getElementById(
                    "predictionResult"
                );

            if (result) {
                result.classList.remove(
                    "hidden"
                );
            }

            /*
             * ==================================
             * PRIMARY PREDICTION
             * ==================================
             */

            setText(
                "prediction",
                data.finalPrediction
            );

            setText(
                "churnProbability",
                formatPercentage(
                    data.churnProbability
                )
            );

            /*
             * ==================================
             * SNA
             * ==================================
             */

            displaySNAFeatures(data);

            /*
             * ==================================
             * ALL ML MODELS
             * ==================================
             */

            displayModelPredictions(
                data.modelPredictions
            );

            showMessage(
                "predictionMessage",
                "Prediction completed."
            );
        })

        .catch(error => {

            const result =
                document.getElementById(
                    "predictionResult"
                );

            if (result) {
                result.classList.add(
                    "hidden"
                );
            }

            showMessage(
                "predictionMessage",
                error.message
            );
        });
}


/*
 * ==========================================
 * DISPLAY SNA FEATURES
 * ==========================================
 */

function displaySNAFeatures(data) {

    /*
     * First use existing HTML elements
     * if they exist.
     */

    setText(
        "inDegree",
        formatNumber(
            data.inDegree
        )
    );

    setText(
        "outDegree",
        formatNumber(
            data.outDegree
        )
    );

    setText(
        "totalDegree",
        formatNumber(
            data.totalDegree
        )
    );

    setText(
        "betweenness",
        formatNumber(
            data.betweenness
        )
    );

    setText(
        "closeness",
        formatNumber(
            data.closeness ??
            data.closenessCentrality
        )
    );

    setText(
        "influence",
        formatNumber(
            data.influence ??
            data.pageRankScore
        )
    );

    setText(
        "conformity",
        formatNumber(
            data.conformity
        )
    );

    /*
     * If the HTML doesn't contain a dedicated
     * SNA section, create one automatically.
     */

    let container =
        document.getElementById(
            "snaFeatures"
        );

    if (!container) {

        const result =
            document.getElementById(
                "predictionResult"
            );

        if (!result) {
            return;
        }

        container =
            document.createElement(
                "div"
            );

        container.id =
            "snaFeatures";

        container.className =
            "sna-features";

        result.appendChild(
            container
        );
    }

    /*
     * Don't duplicate the generated table.
     */
    if (
        container.dataset.generated ===
        "true"
    ) {
        return;
    }

    container.dataset.generated =
        "true";

    container.innerHTML = `

        <h3>Social Network Analysis</h3>

        <table class="table">

            <thead>
                <tr>
                    <th>SNA Feature</th>
                    <th>Value</th>
                </tr>
            </thead>

            <tbody>

                <tr>
                    <td>In Degree</td>
                    <td>
                        ${formatNumber(
                            data.inDegree
                        )}
                    </td>
                </tr>

                <tr>
                    <td>Out Degree</td>
                    <td>
                        ${formatNumber(
                            data.outDegree
                        )}
                    </td>
                </tr>

                <tr>
                    <td>Total Degree</td>
                    <td>
                        ${formatNumber(
                            data.totalDegree
                        )}
                    </td>
                </tr>

                <tr>
                    <td>Betweenness</td>
                    <td>
                        ${formatNumber(
                            data.betweenness
                        )}
                    </td>
                </tr>

                <tr>
                    <td>Closeness</td>
                    <td>
                        ${formatNumber(
                            data.closeness ??
                            data.closenessCentrality
                        )}
                    </td>
                </tr>

                <tr>
                    <td>Influence / PageRank</td>
                    <td>
                        ${formatNumber(
                            data.influence ??
                            data.pageRankScore
                        )}
                    </td>
                </tr>

                <tr>
                    <td>Conformity</td>
                    <td>
                        ${formatNumber(
                            data.conformity
                        )}
                    </td>
                </tr>

            </tbody>

        </table>
    `;
}


/*
 * ==========================================
 * DISPLAY ALL ML MODEL PREDICTIONS
 * ==========================================
 */

function displayModelPredictions(
    models
) {

    const table =
        document.getElementById(
            "modelPredictions"
        );

    if (!table) {
        return;
    }

    table.innerHTML = "";

    if (
        !models ||
        models.length === 0
    ) {

        table.innerHTML = `

            <tr>

                <td colspan="3">
                    No model prediction data available.
                </td>

            </tr>

        `;

        return;
    }

    models.forEach(model => {

        const row =
            document.createElement(
                "tr"
            );

        let probability =
            "-";

        if (
            model.probability !== null &&
            model.probability !== undefined
        ) {

            probability =
                formatPercentage(
                    model.probability
                );
        }

        row.innerHTML = `

            <td>
                ${escapeHtml(
                    model.algorithm ??
                    "-"
                )}
            </td>

            <td>
                ${escapeHtml(
                    model.prediction ??
                    "-"
                )}
            </td>

            <td>
                ${probability}
            </td>

        `;

        table.appendChild(
            row
        );
    });
}


/*
 * ==========================================
 * SAFE TEXT SETTER
 * ==========================================
 */

function setText(
    elementId,
    value
) {

    const element =
        document.getElementById(
            elementId
        );

    if (!element) {
        return;
    }

    element.textContent =
        value === null ||
        value === undefined
            ? "-"
            : value;
}


/*
 * ==========================================
 * NUMBER FORMAT
 * ==========================================
 */

function formatNumber(value) {

    if (
        value === null ||
        value === undefined ||
        Number.isNaN(
            Number(value)
        )
    ) {

        return "0";
    }

    const number =
        Number(value);

    return number.toFixed(4);
}


/*
 * ==========================================
 * PERCENTAGE FORMAT
 * ==========================================
 */

function formatPercentage(value) {

    if (
        value === null ||
        value === undefined ||
        Number.isNaN(
            Number(value)
        )
    ) {

        return "0.00%";
    }

    let number =
        Number(value);

    /*
     * ML probability is normally between
     * 0 and 1.
     */
    if (
        number >= 0 &&
        number <= 1
    ) {

        number =
            number * 100;
    }

    return number.toFixed(2) + "%";
}


/*
 * ==========================================
 * HTML ESCAPING
 * ==========================================
 */

function escapeHtml(value) {

    if (value === null ||
        value === undefined) {

        return "";
    }

    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}