document.addEventListener(
    "DOMContentLoaded",
    function () {

        if (!requireLogin()) {
            return;
        }

        loadEvaluation();
    }
);


async function trainModels() {

    const button =
        document.getElementById(
            "trainButton"
        );

    setButtonLoading(
        button,
        true,
        "Training..."
    );

    showMessage(
        "trainingMessage",
        "Training five machine learning models. Please wait...",
        "info"
    );

    try {

        const data =
            await apiGet(
                "/api/ml/train"
            );

        displayTrainingResult(
            data
        );

        showMessage(
            "trainingMessage",
            "Model training completed successfully.",
            "success"
        );

    } catch (error) {

        showMessage(
            "trainingMessage",
            error.message ||
                "Model training failed.",
            "error"
        );

    } finally {

        setButtonLoading(
            button,
            false
        );
    }
}


async function loadEvaluation() {

    try {

        const data =
            await apiGet(
                "/api/ml/evaluation"
            );

        displayTrainingResult(
            data
        );

    } catch (error) {

        console.log(
            "Evaluation not available yet:",
            error.message
        );
    }
}


function displayTrainingResult(
    data
) {

    if (!data) return;

    document
        .getElementById(
            "trainingSummary"
        )
        .classList.remove(
            "hidden"
        );

    setText(
        "totalRecords",
        data.totalRecords
    );

    setText(
        "trainingRecords",
        data.trainingRecords
    );

    setText(
        "testingRecords",
        data.testingRecords
    );

    setText(
        "featureCount",
        data.featureCount
    );


    const table =
        document.getElementById(
            "evaluationTable"
        );

    table.innerHTML = "";


    if (
        !data.models ||
        data.models.length === 0
    ) {

        table.innerHTML = `
            <tr>
                <td
                    colspan="5"
                    class="table-empty">

                    No evaluation data available.

                </td>
            </tr>
        `;

        return;
    }


    data.models.forEach(
        function (model) {

            const row =
                document.createElement(
                    "tr"
                );

            row.innerHTML = `
                <td>
                    ${escapeHtml(
                        model.algorithm
                    )}
                </td>

                <td>
                    ${formatPercentage(
                        model.accuracy
                    )}
                </td>

                <td>
                    ${formatPercentage(
                        model.precision
                    )}
                </td>

                <td>
                    ${formatPercentage(
                        model.recall
                    )}
                </td>

                <td>
                    ${formatPercentage(
                        model.f1Score
                    )}
                </td>
            `;

            table.appendChild(row);
        }
    );
}