document.addEventListener(
    "DOMContentLoaded",
    function () {

        if (!requireLogin()) {
            return;
        }

        loadDashboard();
        loadHistory();
    }
);


async function loadDashboard() {

    try {

        const data =
            await apiGet(
                "/api/dashboard/summary"
            );

        animateCount(
            document.getElementById(
                "totalPredictions"
            ),
            safeNumber(
                data.totalPredictions
            )
        );

        animateCount(
            document.getElementById(
                "churnPredictions"
            ),
            safeNumber(
                data.churnPredictions
            )
        );

        animateCount(
            document.getElementById(
                "nonChurnPredictions"
            ),
            safeNumber(
                data.nonChurnPredictions
            )
        );

        setText(
            "averageProbability",
            formatPercentage(
                data.averageChurnProbability
            )
        );

    } catch (error) {

        console.error(
            "Dashboard error:",
            error
        );
    }
}


async function loadHistory() {

    const table =
        document.getElementById(
            "historyTable"
        );

    const button =
        document.getElementById(
            "refreshButton"
        );

    setButtonLoading(
        button,
        true,
        "Loading..."
    );

    try {

        const data =
            await apiGet(
                "/api/dashboard/history"
            );

        table.innerHTML = "";

        if (
            !data ||
            data.length === 0
        ) {

            table.innerHTML = `
                <tr>
                    <td
                        colspan="6"
                        class="table-empty">

                        No prediction history found yet.

                    </td>
                </tr>
            `;

            return;
        }

        data.forEach(
            function (item) {

                const row =
                    document.createElement(
                        "tr"
                    );

                row.innerHTML = `
                    <td>
                        <strong>
                            ${escapeHtml(
                                item.customerId ?? "-"
                            )}
                        </strong>
                    </td>

                    <td>
                        ${predictionBadge(
                            item.prediction
                        )}
                    </td>

                    <td>
                        ${formatPercentage(
                            item.churnProbability
                        )}
                    </td>

                    <td>
                        ${formatNumber(
                            item.inDegree
                        )}
                    </td>

                    <td>
                        ${formatNumber(
                            item.outDegree
                        )}
                    </td>

                    <td>
                        ${escapeHtml(
                            formatDate(
                                item.createdAt
                            )
                        )}
                    </td>
                `;

                table.appendChild(row);
            }
        );

    } catch (error) {

        table.innerHTML = `
            <tr>
                <td
                    colspan="6"
                    class="table-empty">

                    ${escapeHtml(
                        error.message
                    )}

                </td>
            </tr>
        `;

    } finally {

        setButtonLoading(
            button,
            false
        );
    }
}


function animateCount(
    element,
    target,
    duration = 800
) {

    if (!element) return;

    const start =
        performance.now();

    function update(now) {

        const progress =
            Math.min(
                (now - start) /
                duration,
                1
            );

        element.textContent =
            Math.round(
                target * progress
            );

        if (progress < 1) {
            requestAnimationFrame(
                update
            );
        }
    }

    requestAnimationFrame(
        update
    );
}